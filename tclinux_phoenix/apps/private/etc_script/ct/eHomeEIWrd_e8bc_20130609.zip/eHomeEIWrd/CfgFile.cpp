// CfgFile.cpp : implementation file
//

#include "stdafx.h"
#include "eHomeEIWrd.h"
#include "CfgFile.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCfgFile

CCfgFile::CCfgFile()
{
	char path[256];

	GetModuleFileName(NULL, path, sizeof(path));
	m_FileName.Format(_T("%s"), path);
	int j = m_FileName.ReverseFind('\\');
	m_FileName = m_FileName.Left(m_FileName.ReverseFind('\\'));
	m_FileName += _T("\\eHomeEIWrd.ini");
}

CCfgFile::~CCfgFile()
{
}




/////////////////////////////////////////////////////////////////////////////
// CCfgFile message handlers
CString CCfgFile::GetString(const CString _appName, const CString _keyName)
{
	char retValue[256];
	GetPrivateProfileString(_appName, _keyName, _T("0"), retValue, sizeof(retValue), m_FileName);
	return retValue;
}

int CCfgFile::GetInt(const CString _appName, const CString _keyName)
{
	char retValue[32];
	GetPrivateProfileString(_appName, _keyName, _T("0"), retValue, sizeof(retValue), m_FileName);
	return atoi(retValue);
}