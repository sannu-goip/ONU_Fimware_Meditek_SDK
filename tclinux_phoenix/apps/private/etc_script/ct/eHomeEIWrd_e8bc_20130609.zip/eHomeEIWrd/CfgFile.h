#if !defined(AFX_CFGFILE_H__6675470A_4677_40CF_BEA1_E296D6495C52__INCLUDED_)
#define AFX_CFGFILE_H__6675470A_4677_40CF_BEA1_E296D6495C52__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CfgFile.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCfgFile window

class CCfgFile : public CStdioFile
{
// Construction
public:
	CCfgFile();
	CString GetString(const CString _appName, const CString _keyName);
	int GetInt(const CString _appName, const CString _keyName);
// Attributes
public:
	CString m_FileName;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCfgFile)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CCfgFile();

	// Generated message map functions
protected:
	//{{AFX_MSG(CCfgFile)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CFGFILE_H__6675470A_4677_40CF_BEA1_E296D6495C52__INCLUDED_)
