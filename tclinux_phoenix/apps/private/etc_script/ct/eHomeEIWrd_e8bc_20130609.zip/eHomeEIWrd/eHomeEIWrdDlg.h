// eHomeEIWrdDlg.h : header file
//

#if !defined(AFX_EHOMEEIWRDDLG_H__5058BE19_CF69_42E2_95AA_4344B1CD48E1__INCLUDED_)
#define AFX_EHOMEEIWRDDLG_H__5058BE19_CF69_42E2_95AA_4344B1CD48E1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h"
#include "CfgFile.h"
#include "ClientSocket.h"

/////////////////////////////////////////////////////////////////////////////
// CEHomeEIWrdDlg dialog
#define APP_MENU					_T("Menu")
#define APP_CAPTION					_T("Caption")
#define APP_OFFSET					_T("Offset")
#define APP_BUTTON					_T("Button")
#define APP_FONT					_T("Font")

#define APP_ERR_MSG					_T("Err_Msg")

#define APP_MODEMCFG				_T("modemCfg")

#define APP_WELCOME_USER			_T("WELCOME_USER")
#define APP_SCAN_PC					_T("SCAN_PC")
#define APP_SELECT_GATEWAY			_T("SELECT_GATEWAY")
#define APP_INTERFACE_INTRO			_T("INTERFACE_INTRO")
#define APP_CONNECT_NETLINE			_T("CONNECT_NETLINE")
#define APP_OPEN_POWER				_T("OPEN_POWER")
#define APP_SCAN_GATEWAY			_T("SCAN_GATEWAY")
#define APP_INPUT_WIFIINFO			_T("INPUT_WIFIINFO")
#define APP_SAVE_WIFIINFO			_T("SAVE_WIFIINFO")
#define APP_SELECT_USEROPER			_T("SELECT_USEROPER")
#define APP_CHANGE_USRPWD			_T("CHANGE_USRPWD")
#define APP_REG_DEVICE				_T("REG_DEVICE")
#define APP_FIN_OPER				_T("FIN_OPER")

#define KEY_LEFT					_T("Left")
#define KEY_TOP						_T("Top")

#define HTTP_PREFIX					_T("http://")
#define HTTP_HEAD_END				_T("</head>")

#define TCAPI_WLAN					_T("tcapi get WLan_Entry0 ")

#define KEY_WAN						_T("INTERNET_R")
#define KEY_SPLIT					_T(",")

#define COLOR_BLUE						RGB(0, 0, 255)
#define COLOR_BROWN						RGB(165, 42, 42)
#define COLOR_GREEN						RGB(46, 139, 87)
#define COLOR_BLACK						RGB(0, 0, 0)
#define COLOR_WHITE						RGB(255, 255, 255)

#define START_BUTTON_WIDTH				100
#define START_BUTTON_HEIGHT				100

#define CHECK_BMP_WIDTH					18
#define CHECK_BMP_HEIGHT				18

#define MAX_BUF_LENGTH					1024

#define MAXHEADERSIZE					1024
#define HTTP_TIMEOUT					3000

//linos
//telnet hint symbol:>tc is 8
//telnet hint symbol:>ZTE is 9
//#define LR_WIN							9

//linux
#define LR_WIN							4

enum OperStep
{
	WELCOME_USER = 0,
	SCAN_PC,
	SELECT_GATEWAY,
	INTERFACE_INTRO,
	CONNECT_NETLINE,
	OPEN_POWER,
	SCAN_GATEWAY,
	INPUT_WIFIINFO,
	SAVE_WIFIINFO,
	SELECT_USEROPER,
	CHANGE_USRPWD,
	//REG_DEVICE,
	FIN_OPER,
};

//telnet��
const	unsigned char IAC		= 255;
const	unsigned char DO		= 253;
const	unsigned char DONT		= 254;
const	unsigned char WILL		= 251;
const	unsigned char WONT		= 252;
const	unsigned char SB		= 250;
const	unsigned char SE		= 240;
const	unsigned char IS		= '0';
const	unsigned char SEND		= '1';
const	unsigned char INFO		= '2';
const	unsigned char VAR		= '0';
const	unsigned char VALUE		= '1';
const	unsigned char ESC		= '2';
const	unsigned char USERVAR	= '3';

const	unsigned int	TIMER_REG=1;//ע���ʱ��
const	unsigned int	TIMER_INTERVAL=5000;
const	unsigned int	UpLimitCount=48;

const	unsigned int	TIMER_REFRESH=9;//ˢ�¼�ʱ��
const	unsigned int	TIMER_INTERVAL_REFRSH=3000;

const	unsigned int	TIMER_UNLOCK=6;
const	unsigned int	TIMER_INTERVAL_UNLOCK=100;

//class CClientSocket;

class CEHomeEIWrdDlg : public CDialog
{
// Construction
public:
	CEHomeEIWrdDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CEHomeEIWrdDlg)
	enum { IDD = IDD_EHOMEEIWRD_DIALOG };
	CProgressCtrl	m_Progress;//������
	CListBox	m_Info;//��ʾtelent������Ϣ��debug��
	CComboBox	m_cmb6;//�û�����ѡ��
	CComboBox	m_cmb5;//����ģʽ
	CComboBox	m_cmb4;//��Կ����
	CComboBox	m_cmb3;//WEP��Կ����
	CComboBox	m_cmb2;//������֤ģʽ
	CComboBox	m_cmb1;//�����ͺ�
	CEdit	m_edt5;//psw
	CEdit	m_edt4;//uid
	CEdit	m_edt3;//wpa key
	CEdit	m_edt2;//wep key
	CEdit	m_edt1;//SSID
	CButton	m_btnClose;
	CButton	m_btnCancel;
	CButton	m_btnPre;
	CButton	m_btnNext;
	CButton	m_btnOK;
	CButton	m_btnBrowser;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEHomeEIWrdDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
public:
	void ProcessMessage(CClientSocket *cSocket);
	void SocketError();

protected:
	HICON m_hIcon;

	//�軭��
	CDC*			m_MainDC;
	CDC*			m_BmpBkDC;
	HBITMAP			m_BmpBkHandle;
	BITMAP			m_Bmp;

	HDC				m_hdcBmp;

	OperStep		m_Step;//��ʾĿǰ�û������ľ��岽��
	CCfgFile		m_CfgFile;//�����ļ�

	int				m_ScanResult;
	int				m_TelnetActive;
	CString			m_GatewayName;
	CString			m_SSIDPrefix;

	CString			m_RemoteGatewayName;

	int				m_LOffset;
	int				m_MOffset;
	int				m_SOffset;

	int				m_SBtnLeft;
	int				m_SBtnTop;

	CClientSocket	*m_pSocket;//telnetͨѶ
	CString			m_SvrHost;
	int				m_SvrPort;
	CString			m_UID;
	CString			m_PSW;

	int				m_Connected;
	int				m_Locked;
	int				m_Locked_CHANGE_USRPWD;

	CByteArray		m_bBuf;
	CString			m_strLine;
	CString			m_strNormalText;
	CStringList		m_ListOptions;
	CString			m_strResp;
	int				m_TimerCounter;

	CString			m_SSID;
	CString			m_AuthMode;
	CString			m_KeyLen;
	CString			m_WEPKey;
	CString			m_KeyID;
	CString			m_WPAKey;
	CString			m_EncrypType;

	int				m_UserOper;//�û�����ѡ��
	int				m_UserSave;

	int				m_SkipWLan;//�Ƿ�����wlan����
	int				m_FindWan;
	int				m_FindReg;

	int				m_retryLimit;
	int				m_retryTimes;
	int				m_TimeOutCnt;
	int				m_registerStatus;
	int				m_registerResult;
	int				m_registerNeedReboot;

	int				m_init_reg;//judge if first returned
	int				m_init_Changed;//judge if returned value changed
	int				m_init_registerStatus;//record first returned registerStatus
	int				m_init_registerResult;//record first returned registerResult

	int				m_RegPageStatus;
	int				m_statusFlag;
	bool			m_isRegSuccess;
	int				m_tryTimesflg;

	CStringArray	m_StrArrGUIName;
	CStringArray	m_StrArrEntryIndex;
	int				m_ArrIndex;
	int				m_WanEntryIndex;

	CString			m_SavedPppName;
	CString			m_SavedPppPassword;
	CString			m_SavedRegName;
	CString			m_SavedRegPassword;

	CTime			m_RegStartTime;
	BOOL			m_bRegStart;
	int				m_TelnetConnected;

	void ShowBtn();
	void ShowCtl();
	void ShowMenu(const OperStep _step, RECT &rect);

	BOOL GetLine(const CByteArray &bytes, int nBytes, int &ndx);
	void ProcessOptions();
	void RespondToOptions();
	void ArrangeReply(CString strOption);
	void DispatchMessage(CString strText);

	//JS check
	bool isValidKey(CString val, int size);
	bool isHexaDigit(char digit);
	bool isValidWPAPskKey(CString val);
	bool isNameUnsafeEx(char compareChar);
	bool isValidNameEx(CString name);

	CString GetRegMsg();
	CString GetMsg();

	int SplitString(const CString& strInputString, const CString& strDelimiter, CStringArray& arrStringArray);

	// Generated message map functions
	//{{AFX_MSG(CEHomeEIWrdDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnOK();
	afx_msg void OnDestroy();
	virtual void OnCancel();
	afx_msg void OnButtonPre();
	afx_msg void OnButtonNext();
	afx_msg void OnButtonClose();
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnSelchangeCombo2();
	afx_msg void OnSelchangeCombo6();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnGotobrowser();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EHOMEEIWRDDLG_H__5058BE19_CF69_42E2_95AA_4344B1CD48E1__INCLUDED_)
