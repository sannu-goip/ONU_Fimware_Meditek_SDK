//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by eHomeEIWrd.rc
//
#define IDGOTOBROWSER                   3
#define IDD_EHOMEEIWRD_DIALOG           102
#define IDR_MAINFRAME                   128
#define ICON_CLOSE                      150
#define IDB_BITMAP_OK                   152
#define IDB_BITMAP_NO                   153
#define IDC_BUTTON_NEXT                 1002
#define IDC_BUTTON_PRE                  1003
#define IDC_BUTTON_CLOSE                1004
#define IDC_COMBO1                      1007
#define IDC_COMBO2                      1008
#define IDC_COMBO3                      1009
#define IDC_COMBO4                      1010
#define IDC_EDIT1                       1011
#define IDC_EDIT2                       1012
#define IDC_LIST_INFO                   1013
#define IDC_COMBO5                      1014
#define IDC_EDIT3                       1015
#define IDC_COMBO6                      1016
#define IDC_EDIT4                       1017
#define IDC_EDIT5                       1018
#define IDC_PROGRESS1                   1019

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        155
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
