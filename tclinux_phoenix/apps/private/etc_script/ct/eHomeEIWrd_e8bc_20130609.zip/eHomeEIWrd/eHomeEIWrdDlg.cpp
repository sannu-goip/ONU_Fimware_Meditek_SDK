// eHomeEIWrdDlg.cpp : implementation file
//

#include "stdafx.h"
#include "eHomeEIWrd.h"
#include "eHomeEIWrdDlg.h"

#include "httpsocket.h"

#include <afxtempl.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEHomeEIWrdDlg dialog

CEHomeEIWrdDlg::CEHomeEIWrdDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CEHomeEIWrdDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CEHomeEIWrdDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CEHomeEIWrdDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CEHomeEIWrdDlg)
	DDX_Control(pDX, IDGOTOBROWSER, m_btnBrowser);
	DDX_Control(pDX, IDC_PROGRESS1, m_Progress);
	DDX_Control(pDX, IDC_LIST_INFO, m_Info);
	DDX_Control(pDX, IDC_COMBO6, m_cmb6);
	DDX_Control(pDX, IDC_COMBO5, m_cmb5);
	DDX_Control(pDX, IDC_COMBO4, m_cmb4);
	DDX_Control(pDX, IDC_COMBO3, m_cmb3);
	DDX_Control(pDX, IDC_COMBO2, m_cmb2);
	DDX_Control(pDX, IDC_COMBO1, m_cmb1);
	DDX_Control(pDX, IDC_EDIT5, m_edt5);
	DDX_Control(pDX, IDC_EDIT4, m_edt4);
	DDX_Control(pDX, IDC_EDIT3, m_edt3);
	DDX_Control(pDX, IDC_EDIT2, m_edt2);
	DDX_Control(pDX, IDC_EDIT1, m_edt1);
	DDX_Control(pDX, IDC_BUTTON_CLOSE, m_btnClose);
	DDX_Control(pDX, IDCANCEL, m_btnCancel);
	DDX_Control(pDX, IDC_BUTTON_PRE, m_btnPre);
	DDX_Control(pDX, IDC_BUTTON_NEXT, m_btnNext);
	DDX_Control(pDX, IDOK, m_btnOK);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CEHomeEIWrdDlg, CDialog)
	//{{AFX_MSG_MAP(CEHomeEIWrdDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_BUTTON_PRE, OnButtonPre)
	ON_BN_CLICKED(IDC_BUTTON_NEXT, OnButtonNext)
	ON_BN_CLICKED(IDC_BUTTON_CLOSE, OnButtonClose)
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_CBN_SELCHANGE(IDC_COMBO2, OnSelchangeCombo2)
	ON_CBN_SELCHANGE(IDC_COMBO6, OnSelchangeCombo6)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDGOTOBROWSER, OnGotobrowser)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEHomeEIWrdDlg message handlers

BOOL CEHomeEIWrdDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	if (!AfxSocketInit())//socket ��ʼ��
	{
		AfxMessageBox(_T("Sockets library failed to initialize."));
		return FALSE;
	}

	// TODO: Add extra initialization here
	m_ScanResult = -1;
	m_TelnetActive = 1;
	m_Connected = 0;
	m_Locked = 0;
	m_Locked_CHANGE_USRPWD = 0;
	m_UserOper = 0;
	m_UserSave = 0;
	m_SkipWLan = 0;
	m_FindWan=0;
	m_FindReg=0;

	m_retryLimit=0;
	m_retryTimes=0;
	m_TimeOutCnt=0;
	m_registerStatus=0;
	m_registerResult=0;
	m_registerNeedReboot=0;
	m_init_reg=1;
	m_init_Changed=0;
	m_init_registerStatus=0;
	m_init_registerResult=0;

	m_RegPageStatus=0;
	m_statusFlag=0;
	m_isRegSuccess=false;
	m_tryTimesflg=0;

	m_ArrIndex=0;
	m_WanEntryIndex=0;

	m_TimerCounter=1;

	m_SavedPppName.Empty();
	m_SavedPppPassword.Empty();
	m_SavedRegName.Empty();
	m_SavedRegPassword.Empty();

	m_bRegStart=false;
	m_TelnetConnected=0;

	m_BmpBkHandle = (HBITMAP)LoadImage(NULL, _T("res\\bk.bmp"), IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	if(m_BmpBkHandle == NULL)
	{
		AfxMessageBox(_T("Load image file fail."), MB_ICONERROR | MB_SYSTEMMODAL | MB_OK);
		exit(1);
	}
	m_MainDC = this->GetDC();
	m_BmpBkDC = new CDC;
	m_BmpBkDC->CreateCompatibleDC(m_MainDC);
	m_BmpBkDC->SelectObject(m_BmpBkHandle);
	GetObject(m_BmpBkHandle, sizeof(BITMAP), &m_Bmp);
	this->MoveWindow(0,0,m_Bmp.bmWidth, m_Bmp.bmHeight);
	m_Step = WELCOME_USER;

	m_hdcBmp = CreateCompatibleDC(m_MainDC->m_hDC);

	m_LOffset = m_CfgFile.GetInt(APP_OFFSET, _T("Large"));
	m_MOffset = m_CfgFile.GetInt(APP_OFFSET, _T("Medium"));
	m_SOffset = m_CfgFile.GetInt(APP_OFFSET, _T("Small"));
	m_SBtnLeft = m_CfgFile.GetInt(APP_BUTTON, KEY_LEFT);
	m_SBtnTop = m_CfgFile.GetInt(APP_BUTTON, KEY_TOP);
	m_btnCancel.SetWindowText(m_CfgFile.GetString(APP_CAPTION, _T("Cancel")));
	m_btnPre.SetWindowText(m_CfgFile.GetString(APP_CAPTION, _T("Previous")));
	m_btnNext.SetWindowText(m_CfgFile.GetString(APP_CAPTION, _T("Next")));
	m_btnBrowser.SetWindowText(m_CfgFile.GetString(APP_CAPTION, _T("Browser")));

	CRect		rect;
	rect.left = m_Bmp.bmWidth-32;
	rect.top = 0;
	rect.right = m_Bmp.bmWidth;
	rect.bottom = 32;
	m_btnClose.MoveWindow(&rect);
	m_btnClose.SetIcon(AfxGetApp()->LoadIcon(ICON_CLOSE));

	ShowBtn();//��ʾ��ť

	m_GatewayName = m_CfgFile.GetString(APP_MODEMCFG, _T("GateWayName"));
	m_SSIDPrefix = m_CfgFile.GetString(APP_MODEMCFG, _T("SSIDPrefix"));

	rect.left = m_CfgFile.GetInt(APP_SELECT_GATEWAY, KEY_LEFT);
	rect.top = m_CfgFile.GetInt(APP_SELECT_GATEWAY, KEY_TOP)+m_MOffset;
	rect.right = rect.left + m_LOffset*2;
	rect.bottom = rect.top + m_LOffset*2;
	m_cmb1.AddString(m_GatewayName);
	m_cmb1.SetCurSel(0);
	m_cmb1.MoveWindow(&rect);
	m_cmb6.AddString(m_CfgFile.GetString(APP_SELECT_USEROPER, _T("Txt2")));
	m_cmb6.AddString(m_CfgFile.GetString(APP_SELECT_USEROPER, _T("Txt3")));
	m_cmb6.SetCurSel(0);
	m_cmb6.MoveWindow(&rect);

	rect.left = m_CfgFile.GetInt(APP_INPUT_WIFIINFO, _T("Left3"));
	rect.top = m_CfgFile.GetInt(APP_INPUT_WIFIINFO, KEY_TOP)+m_MOffset;
	rect.right = m_CfgFile.GetInt(APP_INPUT_WIFIINFO, _T("Left2")) + m_LOffset*2;
	rect.bottom = rect.top + 22;
	m_edt1.MoveWindow(&rect);

	rect.left = m_CfgFile.GetInt(APP_INPUT_WIFIINFO, _T("Left2"));
	rect.top += m_MOffset;
	rect.right = rect.left + m_LOffset*2;
	rect.bottom = rect.top + m_LOffset*2;
	m_cmb2.AddString(m_CfgFile.GetString(APP_INPUT_WIFIINFO, _T("AuthMode1")));
	m_cmb2.AddString(m_CfgFile.GetString(APP_INPUT_WIFIINFO, _T("AuthMode2")));
	m_cmb2.AddString(m_CfgFile.GetString(APP_INPUT_WIFIINFO, _T("AuthMode5")));
	m_cmb2.MoveWindow(&rect);

	rect.top += m_MOffset;
	rect.right = rect.left + m_LOffset*2;
	rect.bottom = rect.top + m_LOffset*2;
	m_cmb3.AddString(m_CfgFile.GetString(APP_INPUT_WIFIINFO, _T("KeyLen1")));
	m_cmb3.AddString(m_CfgFile.GetString(APP_INPUT_WIFIINFO, _T("KeyLen2")));
	m_cmb3.MoveWindow(&rect);
	rect.bottom = rect.top + 22;
	m_edt3.MoveWindow(&rect);

	rect.top += m_MOffset;
	rect.right = rect.left + m_LOffset*2;
	rect.bottom = rect.top + 22;
	m_edt2.MoveWindow(&rect);
	rect.bottom = rect.top + m_LOffset*2;
	m_cmb5.AddString(m_CfgFile.GetString(APP_INPUT_WIFIINFO, _T("EncrypType1")));
	m_cmb5.AddString(m_CfgFile.GetString(APP_INPUT_WIFIINFO, _T("EncrypType2")));
	m_cmb5.AddString(m_CfgFile.GetString(APP_INPUT_WIFIINFO, _T("EncrypType3")));
	m_cmb5.MoveWindow(&rect);

	rect.top += m_MOffset;
	rect.right = rect.left + m_LOffset*2;
	rect.bottom = rect.top + m_LOffset*2;
	m_cmb4.AddString(m_CfgFile.GetString(APP_INPUT_WIFIINFO, _T("KeyID1")));
	m_cmb4.AddString(m_CfgFile.GetString(APP_INPUT_WIFIINFO, _T("KeyID2")));
	m_cmb4.AddString(m_CfgFile.GetString(APP_INPUT_WIFIINFO, _T("KeyID3")));
	m_cmb4.AddString(m_CfgFile.GetString(APP_INPUT_WIFIINFO, _T("KeyID4")));
	m_cmb4.MoveWindow(&rect);

	rect.left = m_CfgFile.GetInt(APP_CHANGE_USRPWD, KEY_LEFT)+4*m_MOffset;
	rect.top = m_CfgFile.GetInt(APP_CHANGE_USRPWD, KEY_TOP)+m_MOffset;
	rect.right = rect.left + m_LOffset*2;
	rect.bottom = rect.top + 22;
	m_edt4.MoveWindow(&rect);

	rect.top += m_MOffset;
	rect.bottom = rect.top + 22;
	m_edt5.MoveWindow(&rect);

	rect.left = m_CfgFile.GetInt(APP_FIN_OPER, _T("Left1"));
	rect.top = m_CfgFile.GetInt(APP_FIN_OPER, _T("Top1"));
	rect.right = rect.left + 400;
	rect.bottom = rect.top + 22;
	m_Progress.SetRange(0,UpLimitCount);
	m_Progress.SetPos(m_TimeOutCnt);
	m_Progress.MoveWindow(&rect);

	m_SvrHost = m_CfgFile.GetString(APP_MODEMCFG, _T("ipAddress"));
	m_SvrPort = m_CfgFile.GetInt(APP_MODEMCFG, _T("port"));
	m_UID = m_CfgFile.GetString(APP_MODEMCFG, _T("UID"));
	m_PSW = m_CfgFile.GetInt(APP_MODEMCFG, _T("PSW"));
	
	m_bBuf.SetSize(MAX_BUF_LENGTH);

	BOOL bOK;
	//telnetͨѶ׼��
	m_pSocket = new CClientSocket(this);
	bOK = m_pSocket->Create();
	if(bOK == TRUE)
	{
		m_pSocket->AsyncSelect(FD_READ | FD_WRITE | FD_CLOSE | FD_CONNECT | FD_OOB);
	}
	else
	{
		AfxMessageBox(_T("Could not create new socket"),MB_OK);
		exit(1);
	}
	
	SetTimer(TIMER_REFRESH,TIMER_INTERVAL_REFRSH,NULL);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CEHomeEIWrdDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		int			nBkMode;
		COLORREF	oldColor;
		CFont		font;
		CFont		*oldFont;
		CRect		rect(0,0,m_Bmp.bmWidth, m_Bmp.bmHeight);
		HBITMAP	hbmp;
		CBitmap bmpOK;
		CBitmap bmpNO;
		CString		sysInfo;
		LONG		rt;
		unsigned long ProcSpeed = 0;

		int select;
		//����ͼ
		BitBlt(m_MainDC->m_hDC,0,0,m_Bmp.bmWidth, m_Bmp.bmHeight,m_BmpBkDC->m_hDC,0,0,SRCCOPY);
		nBkMode = m_MainDC->GetBkMode();
		oldColor = m_MainDC->GetTextColor();
		m_MainDC->SetBkMode(TRANSPARENT);
		font.CreateFont(m_CfgFile.GetInt(APP_FONT, _T("Height")),
						0,
						0,
						0,
						FW_NORMAL,
						FALSE,
						FALSE,
						0,
						ANSI_CHARSET,
						OUT_DEFAULT_PRECIS,
						CLIP_DEFAULT_PRECIS,
						DEFAULT_QUALITY,
						DEFAULT_PITCH   |   FF_SWISS,
						m_CfgFile.GetString(APP_FONT, _T("Name"))); 
		oldFont = m_MainDC->SelectObject(&font);
		switch(m_Step)
		{
		case WELCOME_USER:
			//content
			rect.left = m_CfgFile.GetInt(APP_WELCOME_USER, KEY_LEFT);
			rect.top = m_CfgFile.GetInt(APP_WELCOME_USER, KEY_TOP);
			m_MainDC->DrawText(m_CfgFile.GetString(APP_WELCOME_USER, _T("Txt1")), &rect,DT_LEFT);
			rect.top += m_MOffset;
			m_MainDC->DrawText(m_CfgFile.GetString(APP_WELCOME_USER, _T("Txt2")), &rect,DT_LEFT);
			rect.top += m_MOffset;
			rect.left += m_MOffset;
			m_MainDC->DrawText(m_CfgFile.GetString(APP_WELCOME_USER, _T("Txt3")), &rect,DT_LEFT);
			rect.top += m_SOffset;
			m_MainDC->DrawText(m_CfgFile.GetString(APP_WELCOME_USER, _T("Txt4")), &rect,DT_LEFT);

			//start button
			hbmp = (HBITMAP)LoadImage(NULL, _T("res\\start_off.bmp"), IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
			if(hbmp != NULL)
			{
				SelectObject(m_hdcBmp, hbmp);
				TransparentBlt(m_MainDC->m_hDC,m_SBtnLeft,m_SBtnTop,START_BUTTON_WIDTH,START_BUTTON_HEIGHT,
								m_hdcBmp,0,0,START_BUTTON_WIDTH,START_BUTTON_HEIGHT,COLOR_WHITE);
				DeleteObject(hbmp);
			}

			break;
		case SCAN_PC:
			//content
			rect.left = m_CfgFile.GetInt(APP_SCAN_PC, KEY_LEFT);
			rect.top = m_CfgFile.GetInt(APP_SCAN_PC, KEY_TOP);
			m_MainDC->DrawText(m_CfgFile.GetString(APP_SCAN_PC, _T("Txt1")), &rect,DT_LEFT);
			rect.top += m_MOffset;
			m_MainDC->DrawText(m_CfgFile.GetString(APP_SCAN_PC, _T("Txt2")), &rect,DT_LEFT);
			rect.top += m_MOffset;
			rect.left += m_MOffset;
			m_MainDC->DrawText(m_CfgFile.GetString(APP_SCAN_PC, _T("Txt3")), &rect,DT_LEFT);
			rect.top += m_SOffset;
			m_MainDC->DrawText(m_CfgFile.GetString(APP_SCAN_PC, _T("Txt4")), &rect,DT_LEFT);
			rect.top += m_SOffset;
			m_MainDC->DrawText(m_CfgFile.GetString(APP_SCAN_PC, _T("Txt5")), &rect,DT_LEFT);

			bmpOK.LoadBitmap(IDB_BITMAP_OK);
			bmpNO.LoadBitmap(IDB_BITMAP_NO);			

			rect.left -= m_MOffset;
			rect.top += m_LOffset;
			m_MainDC->DrawText(m_CfgFile.GetString(APP_SCAN_PC, _T("Txt6")), &rect,DT_LEFT);			
			rect.left += m_LOffset*2;
			HKEY hKey;
			rt = RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0"), 0, KEY_READ, &hKey);
			if( ERROR_SUCCESS == rt )
			{
				unsigned long buflen = sizeof( ProcSpeed );
				RegQueryValueEx( hKey, "~MHz", NULL, NULL, (LPBYTE)&ProcSpeed, &buflen );
				RegCloseKey(hKey);
			}
			sysInfo.Format(_T("%ld MHz"),ProcSpeed);
			m_MainDC->DrawText(sysInfo, &rect,DT_LEFT);
			if(ProcSpeed>=100)
				SelectObject(m_hdcBmp, bmpOK);
			else
				SelectObject(m_hdcBmp, bmpNO);
			TransparentBlt(m_MainDC->m_hDC,rect.left+m_LOffset,rect.top,CHECK_BMP_WIDTH,CHECK_BMP_WIDTH,
							m_hdcBmp,0,0,CHECK_BMP_WIDTH,CHECK_BMP_WIDTH,COLOR_WHITE);			
			rect.left -= m_LOffset*2;

			rect.top += m_MOffset;
			m_MainDC->DrawText(m_CfgFile.GetString(APP_SCAN_PC, _T("Txt7")), &rect,DT_LEFT);
			rect.left += m_LOffset*2;
			MEMORYSTATUS mem;
			GlobalMemoryStatus(&mem);
			sysInfo.Format(_T("%d MB"),mem.dwTotalPhys/(1024*1024));
			m_MainDC->DrawText(sysInfo, &rect,DT_LEFT);
			if(mem.dwTotalPhys/(1024*1024)>=32)
				SelectObject(m_hdcBmp, bmpOK);
			else
				SelectObject(m_hdcBmp, bmpNO);
			TransparentBlt(m_MainDC->m_hDC,rect.left+m_LOffset,rect.top,CHECK_BMP_WIDTH,CHECK_BMP_WIDTH,
							m_hdcBmp,0,0,CHECK_BMP_WIDTH,CHECK_BMP_WIDTH,COLOR_WHITE);
			rect.left -= m_LOffset*2;

			rect.top += m_MOffset;
			m_MainDC->DrawText(m_CfgFile.GetString(APP_SCAN_PC, _T("Txt8")), &rect,DT_LEFT);
			rect.left += m_LOffset*2;
			DWORD sector,byte,cluster,free;
			unsigned long freespace;
			GetDiskFreeSpace(_T("C:"),&sector,&byte,&free,&cluster);
			freespace=free*byte/1024*sector/1024;
			sysInfo.Format(_T("%u MB"),freespace);
			m_MainDC->DrawText(sysInfo, &rect,DT_LEFT);
			if(freespace>=100)
				SelectObject(m_hdcBmp, bmpOK);
			else
				SelectObject(m_hdcBmp, bmpNO);
			TransparentBlt(m_MainDC->m_hDC,rect.left+m_LOffset,rect.top,CHECK_BMP_WIDTH,CHECK_BMP_WIDTH,
							m_hdcBmp,0,0,CHECK_BMP_WIDTH,CHECK_BMP_WIDTH,COLOR_WHITE);

			DeleteObject(bmpOK);
			DeleteObject(bmpNO);

			break;
		case SELECT_GATEWAY:
			//content
			rect.left = m_CfgFile.GetInt(APP_SELECT_GATEWAY, KEY_LEFT);
			rect.top = m_CfgFile.GetInt(APP_SELECT_GATEWAY, KEY_TOP);
			m_MainDC->DrawText(m_CfgFile.GetString(APP_SELECT_GATEWAY, _T("Txt1")), &rect,DT_LEFT);

			break;
		case INTERFACE_INTRO:
			//content
			rect.left = m_CfgFile.GetInt(APP_INTERFACE_INTRO, KEY_LEFT);
			rect.top = m_CfgFile.GetInt(APP_INTERFACE_INTRO, KEY_TOP);
			hbmp = (HBITMAP)LoadImage(NULL, _T("res\\modem-big.bmp"), IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
			if(hbmp != NULL)
			{	
				SelectObject(m_hdcBmp, hbmp);
				BitBlt(m_MainDC->m_hDC,rect.left,rect.top,
						m_Bmp.bmWidth, m_Bmp.bmHeight,m_hdcBmp,0,0,SRCCOPY);
				//StretchBlt(m_MainDC->m_hDC,rect.left,rect.top,
				//		m_Bmp.bmWidth/2, m_Bmp.bmHeight/2,m_hdcBmp,0,0,m_Bmp.bmWidth,m_Bmp.bmHeight,SRCCOPY);
				DeleteObject(hbmp);
			}
			rect.left = m_CfgFile.GetInt(APP_INTERFACE_INTRO, _T("Left1"));
			rect.top = m_CfgFile.GetInt(APP_INTERFACE_INTRO, _T("Top1"));
			m_MainDC->SetTextColor(COLOR_BLUE);
			m_MainDC->DrawText(m_CfgFile.GetString(APP_INTERFACE_INTRO, _T("Txt1")), &rect,DT_LEFT);
			m_MainDC->SetTextColor(COLOR_BLACK);
			rect.top += m_SOffset*2;
			m_MainDC->DrawText(m_CfgFile.GetString(APP_INTERFACE_INTRO, _T("Txt2")), &rect,DT_LEFT);
			rect.top += m_SOffset;
			m_MainDC->DrawText(m_CfgFile.GetString(APP_INTERFACE_INTRO, _T("Txt3")), &rect,DT_LEFT);
			
			break;
		case CONNECT_NETLINE:
			//content
			rect.left = m_CfgFile.GetInt(APP_CONNECT_NETLINE, KEY_LEFT);
			rect.top = m_CfgFile.GetInt(APP_CONNECT_NETLINE, KEY_TOP);
			hbmp = (HBITMAP)LoadImage(NULL, _T("res\\connect.bmp"), IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
			if(hbmp != NULL)
			{	
				SelectObject(m_hdcBmp, hbmp);
				BitBlt(m_MainDC->m_hDC,rect.left,rect.top,
						m_Bmp.bmWidth, m_Bmp.bmHeight,m_hdcBmp,0,0,SRCCOPY);
				DeleteObject(hbmp);
			}

			break;
		case OPEN_POWER:
			//content
			rect.left = m_CfgFile.GetInt(APP_OPEN_POWER, KEY_LEFT);
			rect.top = m_CfgFile.GetInt(APP_OPEN_POWER, KEY_TOP);
			hbmp = (HBITMAP)LoadImage(NULL, _T("res\\power.bmp"), IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
			if(hbmp != NULL)
			{	
				SelectObject(m_hdcBmp, hbmp);
				BitBlt(m_MainDC->m_hDC,rect.left,rect.top,
						m_Bmp.bmWidth, m_Bmp.bmHeight,m_hdcBmp,0,0,SRCCOPY);
				DeleteObject(hbmp);
			}
			rect.left = m_CfgFile.GetInt(APP_OPEN_POWER, _T("Left1"));
			rect.top = m_CfgFile.GetInt(APP_OPEN_POWER, _T("Top1"));
			m_MainDC->DrawText(m_CfgFile.GetString(APP_OPEN_POWER, _T("Txt1")), &rect,DT_LEFT);
			rect.left = m_CfgFile.GetInt(APP_OPEN_POWER, _T("Left2"));
			rect.top = m_CfgFile.GetInt(APP_OPEN_POWER, _T("Top2"));
			m_MainDC->DrawText(m_CfgFile.GetString(APP_OPEN_POWER, _T("Txt2")), &rect,DT_LEFT);
			rect.left = m_CfgFile.GetInt(APP_OPEN_POWER, _T("Left3"));
			rect.top = m_CfgFile.GetInt(APP_OPEN_POWER, _T("Top3"));
			m_MainDC->DrawText(m_CfgFile.GetString(APP_OPEN_POWER, _T("Txt3")), &rect,DT_LEFT);

			break;
		case SCAN_GATEWAY:
			//content
			rect.left = m_CfgFile.GetInt(APP_SCAN_GATEWAY, KEY_LEFT);
			rect.top = m_CfgFile.GetInt(APP_SCAN_GATEWAY, KEY_TOP);
			m_MainDC->DrawText(m_CfgFile.GetString(APP_SCAN_GATEWAY, _T("Txt1"))+_T(" ")+m_GatewayName+_T(" :"), &rect,DT_LEFT);

			rect.left += m_MOffset;
			rect.top += m_MOffset;

			bmpOK.LoadBitmap(IDB_BITMAP_OK);
			bmpNO.LoadBitmap(IDB_BITMAP_NO);

			if(m_ScanResult==1){
				SelectObject(m_hdcBmp, bmpOK);
				TransparentBlt(m_MainDC->m_hDC,rect.left,rect.top,CHECK_BMP_WIDTH,CHECK_BMP_WIDTH,
								m_hdcBmp,0,0,CHECK_BMP_WIDTH,CHECK_BMP_WIDTH,COLOR_WHITE);
				rect.left += m_MOffset;
				m_MainDC->DrawText(m_CfgFile.GetString(APP_SCAN_GATEWAY, _T("Txt2"))+_T(" ")+m_GatewayName, &rect,DT_LEFT);
			}
			else{				
				SelectObject(m_hdcBmp, bmpNO);
				TransparentBlt(m_MainDC->m_hDC,rect.left,rect.top,CHECK_BMP_WIDTH,CHECK_BMP_WIDTH,
								m_hdcBmp,0,0,CHECK_BMP_WIDTH,CHECK_BMP_WIDTH,COLOR_WHITE);
				rect.left += m_MOffset;
				m_MainDC->DrawText(m_CfgFile.GetString(APP_SCAN_GATEWAY, _T("Txt3"))+_T(" ")+m_GatewayName, &rect,DT_LEFT);
			}
			DeleteObject(bmpOK);
			DeleteObject(bmpNO);

			break;
		case INPUT_WIFIINFO:
			//content
			rect.left = m_CfgFile.GetInt(APP_INPUT_WIFIINFO, KEY_LEFT);
			rect.top = m_CfgFile.GetInt(APP_INPUT_WIFIINFO, KEY_TOP);
			m_MainDC->DrawText(m_CfgFile.GetString(APP_INPUT_WIFIINFO, _T("Txt1")), &rect,DT_LEFT);
			rect.top += m_MOffset;
			rect.left += m_MOffset;
			m_MainDC->DrawText(m_CfgFile.GetString(APP_INPUT_WIFIINFO, _T("Txt2")), &rect,DT_LEFT);
			rect.top += m_MOffset;
			m_MainDC->DrawText(m_CfgFile.GetString(APP_INPUT_WIFIINFO, _T("Txt3")), &rect,DT_LEFT);
			
			select = m_cmb2.GetCurSel();
			if(select>=2){
				rect.top += m_MOffset;
				m_MainDC->DrawText(m_CfgFile.GetString(APP_INPUT_WIFIINFO, _T("Txt7")), &rect,DT_LEFT);
				rect.top += m_MOffset;
				m_MainDC->DrawText(m_CfgFile.GetString(APP_INPUT_WIFIINFO, _T("Txt8")), &rect,DT_LEFT);
			}
			else if(select==1){
				rect.top += m_MOffset;
				m_MainDC->DrawText(m_CfgFile.GetString(APP_INPUT_WIFIINFO, _T("Txt4")), &rect,DT_LEFT);
				rect.top += m_MOffset;
				m_MainDC->DrawText(m_CfgFile.GetString(APP_INPUT_WIFIINFO, _T("Txt5")), &rect,DT_LEFT);
				rect.top += m_MOffset;
				m_MainDC->DrawText(m_CfgFile.GetString(APP_INPUT_WIFIINFO, _T("Txt6")), &rect,DT_LEFT);
			}
			else{

			}

			rect.left = m_CfgFile.GetInt(APP_INPUT_WIFIINFO, _T("Left2"));
			rect.top = m_CfgFile.GetInt(APP_INPUT_WIFIINFO, KEY_TOP)+m_MOffset;
			m_MainDC->DrawText(m_SSIDPrefix, &rect,DT_LEFT);

			break;
		case SAVE_WIFIINFO:
			//content
			rect.left = m_CfgFile.GetInt(APP_SAVE_WIFIINFO, KEY_LEFT);
			rect.top = m_CfgFile.GetInt(APP_SAVE_WIFIINFO, KEY_TOP);
			m_MainDC->DrawText(m_CfgFile.GetString(APP_SAVE_WIFIINFO, _T("Txt1")), &rect,DT_LEFT);

			rect.left += m_MOffset;
			rect.top += m_MOffset;
			bmpOK.LoadBitmap(IDB_BITMAP_OK);
			bmpNO.LoadBitmap(IDB_BITMAP_NO);
			if(0){
				SelectObject(m_hdcBmp, bmpNO);
				TransparentBlt(m_MainDC->m_hDC,rect.left,rect.top,CHECK_BMP_WIDTH,CHECK_BMP_WIDTH,
								m_hdcBmp,0,0,CHECK_BMP_WIDTH,CHECK_BMP_WIDTH,COLOR_WHITE);
				rect.left += m_MOffset;
				m_MainDC->DrawText(m_CfgFile.GetString(APP_SAVE_WIFIINFO, _T("Txt3")), &rect,DT_LEFT);
			}
			else{
				SelectObject(m_hdcBmp, bmpOK);
				TransparentBlt(m_MainDC->m_hDC,rect.left,rect.top,CHECK_BMP_WIDTH,CHECK_BMP_WIDTH,
								m_hdcBmp,0,0,CHECK_BMP_WIDTH,CHECK_BMP_WIDTH,COLOR_WHITE);
				rect.left += m_MOffset;
				m_MainDC->DrawText(m_CfgFile.GetString(APP_SAVE_WIFIINFO, _T("Txt2")), &rect,DT_LEFT);
			}

			DeleteObject(bmpOK);
			DeleteObject(bmpNO);
			break;
		case SELECT_USEROPER:
			//content
			rect.left = m_CfgFile.GetInt(APP_SELECT_USEROPER, KEY_LEFT);
			rect.top = m_CfgFile.GetInt(APP_SELECT_USEROPER, KEY_TOP);
			m_MainDC->DrawText(m_CfgFile.GetString(APP_SELECT_USEROPER, _T("Txt1")), &rect,DT_LEFT);

			break;
		case CHANGE_USRPWD:
			//content
			if(m_UserOper==0){
				rect.left = m_CfgFile.GetInt(APP_CHANGE_USRPWD, KEY_LEFT);
				rect.top = m_CfgFile.GetInt(APP_CHANGE_USRPWD, KEY_TOP);
				
				if(m_FindWan==1){
					m_MainDC->DrawText(m_CfgFile.GetString(APP_CHANGE_USRPWD, _T("Txt1")), &rect,DT_LEFT);

					rect.top += m_MOffset;
					rect.left += m_MOffset;
					m_MainDC->DrawText(m_CfgFile.GetString(APP_CHANGE_USRPWD, _T("Txt2")), &rect,DT_LEFT);
					rect.top += m_MOffset;
					m_MainDC->DrawText(m_CfgFile.GetString(APP_CHANGE_USRPWD, _T("Txt3")), &rect,DT_LEFT);
				}
				else{
					rect.left -= m_MOffset;
					m_MainDC->DrawText(m_CfgFile.GetString(APP_CHANGE_USRPWD, _T("Txt5")), &rect,DT_LEFT);
				}

			}
			else{
		//	break;
		//case REG_DEVICE:
				//content
				rect.left = m_CfgFile.GetInt(APP_REG_DEVICE, KEY_LEFT);
				rect.top = m_CfgFile.GetInt(APP_REG_DEVICE, KEY_TOP);

				if(m_FindWan==1){
					if(m_FindReg==1){
						m_MainDC->DrawText(m_CfgFile.GetString(APP_REG_DEVICE, _T("Txt1")), &rect,DT_LEFT);

						rect.top += m_MOffset;
						rect.left += m_MOffset;
						m_MainDC->DrawText(m_CfgFile.GetString(APP_REG_DEVICE, _T("Txt2")), &rect,DT_LEFT);
						rect.top += m_MOffset;
						m_MainDC->DrawText(m_CfgFile.GetString(APP_REG_DEVICE, _T("Txt3")), &rect,DT_LEFT);
					}
					else{
						rect.left -= m_MOffset;
						m_MainDC->DrawText(m_CfgFile.GetString(APP_REG_DEVICE, _T("Txt7")), &rect,DT_LEFT);
					}
				}
				else{
					rect.left -= m_MOffset;
					m_MainDC->DrawText(m_CfgFile.GetString(APP_REG_DEVICE, _T("Txt5")), &rect,DT_LEFT);
				}
			}

			break;
		case FIN_OPER:
			//content
			rect.left = m_CfgFile.GetInt(APP_FIN_OPER, KEY_LEFT);
			rect.top = m_CfgFile.GetInt(APP_FIN_OPER, KEY_TOP);
			
			bmpOK.LoadBitmap(IDB_BITMAP_OK);
			bmpNO.LoadBitmap(IDB_BITMAP_NO);
			if(0){
				SelectObject(m_hdcBmp, bmpNO);
				TransparentBlt(m_MainDC->m_hDC,rect.left,rect.top,CHECK_BMP_WIDTH,CHECK_BMP_WIDTH,
								m_hdcBmp,0,0,CHECK_BMP_WIDTH,CHECK_BMP_WIDTH,COLOR_WHITE);
				rect.left += m_MOffset;
				m_MainDC->DrawText(m_CfgFile.GetString(APP_FIN_OPER, _T("Txt1")), &rect,DT_LEFT);
			}
			else{
				if(m_UserOper==1){
					rect.left += m_MOffset;
					m_MainDC->DrawText(GetRegMsg(), &rect,DT_LEFT);
				}
				else{
					SelectObject(m_hdcBmp, bmpOK);
					TransparentBlt(m_MainDC->m_hDC,rect.left,rect.top,CHECK_BMP_WIDTH,CHECK_BMP_WIDTH,
									m_hdcBmp,0,0,CHECK_BMP_WIDTH,CHECK_BMP_WIDTH,COLOR_WHITE);
					rect.left += m_MOffset;
					m_MainDC->DrawText(m_CfgFile.GetString(APP_FIN_OPER, _T("Txt1")), &rect,DT_LEFT);
				}
			}

			DeleteObject(bmpOK);
			DeleteObject(bmpNO);

			break;
		default :
			break;
		}
		//menu
		ShowMenu(m_Step,rect);
		ShowBtn();
		m_MainDC->SetBkMode(nBkMode);
		m_MainDC->SetTextColor(oldColor);
		m_MainDC->SelectObject(oldFont);
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CEHomeEIWrdDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CEHomeEIWrdDlg::OnOK() 
{
	CString setValue;
	CString tmpValue;
	CString value1;
	CString value2;
	int keyLen=5;

	if(m_Locked==1)
		return;
	// TODO: Add extra validation here

	switch(m_Step)
	{
	case SCAN_GATEWAY:
		m_Step=(OperStep)(m_Step-1);
		OnButtonNext();
		break;
	case INPUT_WIFIINFO:
		m_edt1.GetWindowText(value1);
		if(value1.IsEmpty()){
			AfxMessageBox(m_CfgFile.GetString(APP_ERR_MSG, _T("Err1")),MB_OK);
			Invalidate(false);
			OnPaint();
			return;
		}
		if(value1.GetLength()>23){
			AfxMessageBox(m_CfgFile.GetString(APP_ERR_MSG, _T("Err9")),MB_OK);
			Invalidate(false);
			OnPaint();
			return;
		}
		if(m_cmb2.GetCurSel()>=2){
			setValue.Format(_T("tcapi set WLan_Entry0 SSID ChinaNet-%s\r\n"),value1);
			setValue += _T("tcapi set WLan_Entry0 AuthMode WPAPSKWPA2PSK\r\n");
			m_edt3.GetWindowText(value2);

			if(isValidWPAPskKey(value2) == false){
				AfxMessageBox(m_CfgFile.GetString(APP_ERR_MSG, _T("Err4")),MB_OK);
				Invalidate(false);
				OnPaint();
				return;
			}

			tmpValue.Format(_T("tcapi set WLan_Entry0 WPAPSK %s\r\n"),value2);
			setValue += tmpValue;
			if(m_cmb5.GetCurSel()>=2){
				tmpValue=_T("tcapi set WLan_Entry0 EncrypType TKIPAES\r\n");
			}
			else if(m_cmb5.GetCurSel()==1){
				tmpValue=_T("tcapi set WLan_Entry0 EncrypType TKIP\r\n");
			}
			else
				tmpValue=_T("tcapi set WLan_Entry0 EncrypType AES\r\n");
			
			setValue += tmpValue;
		}
		else if(m_cmb2.GetCurSel()==1)
		{
			setValue.Format(_T("tcapi set WLan_Entry0 SSID ChinaNet-%s\r\n"),value1);
			if(m_cmb3.GetCurSel()==1){
				setValue += _T("tcapi set WLan_Entry0 AuthMode WEP-128Bits\r\n");
				keyLen = 13;
			}
			else{
				setValue += _T("tcapi set WLan_Entry0 AuthMode WEP-64Bits\r\n");
				keyLen = 5;
			}
			m_edt2.GetWindowText(value2);

			if(isValidKey(value2,keyLen) == false){
				if(keyLen == 13)
					tmpValue.Format(m_CfgFile.GetString(APP_ERR_MSG, _T("Err3")),value2);
				else
					tmpValue.Format(m_CfgFile.GetString(APP_ERR_MSG, _T("Err2")),value2);

				AfxMessageBox(tmpValue,MB_OK);
				Invalidate(false);
				OnPaint();
				return;
			}

			tmpValue.Format(_T("tcapi set WLan_Entry0 Key%dStr %s\r\n"),m_cmb4.GetCurSel()+1,value2);
			setValue += tmpValue;
			tmpValue.Format(_T("tcapi set WLan_Entry0 DefaultKeyID %d\r\n"),m_cmb4.GetCurSel()+1);
			setValue += tmpValue;
		}
		else{
			setValue.Format(_T("tcapi set WLan_Entry0 SSID ChinaNet-%s\r\n"),value1);
			setValue += _T("tcapi set WLan_Entry0 AuthMode OPEN\r\n");
		}

		SetCapture();
		BeginWaitCursor();

		setValue += _T("tcapi commit WLan_Entry0\r\n");
		setValue += _T("tcapi save\r\n");
		DispatchMessage(setValue);
		m_Locked = 1;

		break;
	case CHANGE_USRPWD:
//	case REG_DEVICE:
		if(m_UserOper==0){
			if(m_FindWan==0){
				m_Step=(OperStep)(m_Step-1);
				m_Locked_CHANGE_USRPWD = 0;//can not find wan,unlock it,otherwise it will never unlcok
				//OnButtonNext();
				Invalidate(false);
				OnPaint();
				break;
			}
		}
		else{
			if((m_FindWan==0)||(m_FindReg==0)){
				m_Step=(OperStep)(m_Step-1);
				m_Locked_CHANGE_USRPWD = 0;//can not find wan/reg,unlock it,otherwise it will never unlcok
				//OnButtonNext();
				Invalidate(false);
				OnPaint();
				break;
			}
		}

		m_edt4.GetWindowText(value1);
		m_edt5.GetWindowText(value2);

		if(m_UserOper==1){
			if((m_bRegStart)&&(m_retryLimit - m_retryTimes<= 0)){
				CTimeSpan	ts=CTime::GetCurrentTime()-m_RegStartTime;
				if(ts.GetTotalSeconds() < 180){//wait 3 miniutes
					AfxMessageBox(m_CfgFile.GetString(APP_FIN_OPER, _T("Msg15")),MB_OK);
					Invalidate(false);
					OnPaint();
					return;
				}
			}
			if((value1.IsEmpty())||(value1.GetLength()>128)){//bandName
				AfxMessageBox(m_CfgFile.GetString(APP_ERR_MSG, _T("Err7")),MB_OK);
				Invalidate(false);
				OnPaint();
				return;
			}
			if((value2.IsEmpty())||(value2.GetLength()>128)){//customer
				AfxMessageBox(m_CfgFile.GetString(APP_ERR_MSG, _T("Err8")),MB_OK);
				Invalidate(false);
				OnPaint();
				return;
			}
			m_UserSave=m_UserSave|2;
			setValue.Format(_T("tcapi set Cwmp_Entry devregInform 1\r\n"));
			tmpValue.Format(_T("tcapi set deviceAccount_Entry userName %s\r\n"),value1);
			setValue += tmpValue;
			tmpValue.Format(_T("tcapi set deviceAccount_Entry userPasswordDEV %s\r\n"),value2);
			setValue += tmpValue;
			/*
			if((m_registerStatus != 0)&&(m_registerStatus != 5)){
				tmpValue.Format(_T("tcapi set deviceAccount_Entry registerStatus 99\r\n"));
				setValue += tmpValue;
				tmpValue.Format(_T("tcapi set deviceAccount_Entry registerResult 99\r\n"));
				setValue += tmpValue;
			}
			*/
			//tmpValue.Format(_T("tcapi set deviceAccount_Entry registerStatus 99\r\n"));
			//setValue += tmpValue;
				
			setValue += _T("tcapi commit deviceAccount_Entry\r\n");
			
			m_TimeOutCnt=0;
			m_Progress.SetPos(m_TimeOutCnt);
			m_registerStatus=0;
			m_registerResult=0;
			m_registerNeedReboot=0;
			m_init_reg=1;
			m_init_Changed=0;
			m_init_registerStatus=99;
			m_init_registerResult=99;
			m_statusFlag=0;
			m_retryLimit=0;

			m_RegPageStatus=1;

			m_SavedRegName=value1;
			m_SavedRegPassword=value2;

			m_RegStartTime=CTime::GetCurrentTime();
			m_bRegStart=true;
		}
		else{
			if((value1.IsEmpty())||(isValidNameEx(value1)==false)||(value1.GetLength()>63)){//pppUserName
				AfxMessageBox(m_CfgFile.GetString(APP_ERR_MSG, _T("Err5")),MB_OK);
				Invalidate(false);
				OnPaint();
				return;
			}
			if((value2.IsEmpty())||(isValidNameEx(value2)==false)||(value2.GetLength()>63)){//pppPassword
				AfxMessageBox(m_CfgFile.GetString(APP_ERR_MSG, _T("Err6")),MB_OK);
				Invalidate(false);
				OnPaint();
				return;
			}
			m_UserSave=m_UserSave|1;
			setValue.Format(_T("tcapi set Wan_PVC%d_Entry%d USERNAME %s\r\n"),m_WanEntryIndex/8,m_WanEntryIndex%8,value1);
			tmpValue.Format(_T("tcapi set Wan_PVC%d_Entry%d PASSWORD %s\r\n"),m_WanEntryIndex/8,m_WanEntryIndex%8,value2);
			setValue += tmpValue;
			tmpValue.Format(_T("tcapi commit Wan_PVC%d_Entry%d\r\n"),m_WanEntryIndex/8,m_WanEntryIndex%8);
			setValue += tmpValue;
			m_SavedPppName=value1;
			m_SavedPppPassword=value2;
		}

		SetCapture();
		BeginWaitCursor();
		
		setValue += _T("tcapi save\r\n");
		DispatchMessage(setValue);
		m_Locked = 1;

		break;
	case FIN_OPER:
		if(m_UserSave&0x3){//both save
			OnButtonClose();
		}
		break;
	case SELECT_GATEWAY:
	case INTERFACE_INTRO:
	case CONNECT_NETLINE:
	case OPEN_POWER:
	case SCAN_PC:
	case SELECT_USEROPER:
	case SAVE_WIFIINFO:
	case WELCOME_USER:
	default :
		break;
	}
}

void CEHomeEIWrdDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// TODO: Add your message handler code here
	//http
	CHttpSocket HttpSocket;
	CString strServer,strObject;
	unsigned short nPort;
	DWORD dwServiceType;
	long nLength;
	const char *pRequestHeader = NULL;
	CString url;
	int nLineSize = 0;
	char szLine[256];

	DeleteDC(m_hdcBmp);
	m_BmpBkDC->DeleteDC();
	delete m_BmpBkDC;
	if(m_pSocket)
		m_pSocket->Close();
	delete m_pSocket;

	KillTimer(TIMER_REG);
	KillTimer(TIMER_REFRESH);

	if((m_ScanResult==1)&&(m_TelnetActive==0)){
		url = HTTP_PREFIX+m_SvrHost+m_CfgFile.GetString(APP_MODEMCFG, _T("Url2"));
		AfxParseURL(url,dwServiceType,strServer,strObject,nPort);
		
		pRequestHeader = HttpSocket.FormatRequestHeader((LPTSTR)(LPCTSTR)strServer,(LPTSTR)(LPCTSTR)strObject,nLength);	
		HttpSocket.Socket();
		HttpSocket.Connect((LPTSTR)(LPCTSTR)strServer);
		HttpSocket.SetTimeout(HTTP_TIMEOUT,0);
		HttpSocket.SendRequest();
		while(nLineSize != -1)
		{
			nLineSize = HttpSocket.GetResponseLine(szLine,256);
			if(nLineSize > -1)
			{
				szLine[nLineSize] = '\0';
			}
		}
	}
}

void CEHomeEIWrdDlg::OnCancel() 
{
	// TODO: Add extra cleanup here
	m_btnCancel.EnableWindow(false);

	if(m_Step==SCAN_GATEWAY){
		m_SkipWLan=1;
		m_Step=SAVE_WIFIINFO;
		OnButtonNext();
	}
	else{
		OnButtonClose();
	}

	SetTimer(TIMER_UNLOCK, TIMER_INTERVAL_UNLOCK, NULL);
//	CDialog::OnCancel();
}

void CEHomeEIWrdDlg::ShowBtn() 
{
	switch(m_Step)
	{
	case SCAN_PC:
		m_btnCancel.ShowWindow(SW_HIDE);
		m_btnPre.ShowWindow(SW_HIDE);
		m_btnNext.ShowWindow(SW_SHOW);
		m_btnOK.ShowWindow(SW_HIDE);
		break;
	case SELECT_GATEWAY:
	case INTERFACE_INTRO:
	case CONNECT_NETLINE:
	case OPEN_POWER:
	case SAVE_WIFIINFO:
	case FIN_OPER:
		if(m_Step==FIN_OPER)
			m_btnCancel.ShowWindow(SW_SHOW);
		else
			m_btnCancel.ShowWindow(SW_HIDE);
		m_btnPre.ShowWindow(SW_SHOW);
		m_btnNext.ShowWindow(SW_SHOW);

		if((m_Step==FIN_OPER) && ((m_UserSave&0x3)==0x3)){//both save
			m_btnOK.ShowWindow(SW_HIDE);//m_btnOK.ShowWindow(SW_SHOW);
		}
		else
			m_btnOK.ShowWindow(SW_HIDE);
		break;
	case SELECT_USEROPER:
	case SCAN_GATEWAY:
		m_btnPre.ShowWindow(SW_HIDE);
		if(m_ScanResult==1){
			m_btnNext.ShowWindow(SW_SHOW);
			if(m_Step==SCAN_GATEWAY)
				m_btnCancel.ShowWindow(SW_SHOW);
			else
				m_btnCancel.ShowWindow(SW_HIDE);
		}
		else{
			m_btnNext.ShowWindow(SW_HIDE);
			m_btnCancel.ShowWindow(SW_HIDE);
		}
		if((m_Step==SCAN_GATEWAY)&&(m_ScanResult!=1))
			m_btnOK.ShowWindow(SW_SHOW);
		else
			m_btnOK.ShowWindow(SW_HIDE);
		break;
	case INPUT_WIFIINFO:
	case CHANGE_USRPWD:
//	case REG_DEVICE:
		m_btnCancel.ShowWindow(SW_HIDE);
		m_btnPre.ShowWindow(SW_SHOW);
		m_btnNext.ShowWindow(SW_HIDE);
		m_btnOK.ShowWindow(SW_SHOW);
		break;
	case WELCOME_USER:
	default :
		m_btnCancel.ShowWindow(SW_HIDE);
		m_btnPre.ShowWindow(SW_HIDE);
		m_btnNext.ShowWindow(SW_HIDE);
		m_btnOK.ShowWindow(SW_HIDE);
		break;
	}
	if(m_ScanResult==1)
		m_btnBrowser.ShowWindow(SW_SHOW);
	else
		m_btnBrowser.ShowWindow(SW_HIDE);

	ShowCtl();
}

void CEHomeEIWrdDlg::ShowCtl() 
{
	int select;
	switch(m_Step)
	{
	case SELECT_GATEWAY:
		m_cmb1.ShowWindow(SW_SHOW);
		m_cmb2.ShowWindow(SW_HIDE);
		m_cmb3.ShowWindow(SW_HIDE);
		m_cmb4.ShowWindow(SW_HIDE);
		m_cmb5.ShowWindow(SW_HIDE);
		m_cmb6.ShowWindow(SW_HIDE);
		m_edt1.ShowWindow(SW_HIDE);
		m_edt2.ShowWindow(SW_HIDE);
		m_edt3.ShowWindow(SW_HIDE);
		m_edt4.ShowWindow(SW_HIDE);
		m_edt5.ShowWindow(SW_HIDE);
		m_Progress.ShowWindow(SW_HIDE);
		break;
	case INPUT_WIFIINFO:
		m_cmb1.ShowWindow(SW_HIDE);
		m_cmb2.ShowWindow(SW_SHOW);
		m_cmb6.ShowWindow(SW_HIDE);
		m_edt1.ShowWindow(SW_SHOW);
		m_edt4.ShowWindow(SW_HIDE);
		m_edt5.ShowWindow(SW_HIDE);
		m_Progress.ShowWindow(SW_HIDE);
		select = m_cmb2.GetCurSel();
		if(select>=2){
			m_cmb3.ShowWindow(SW_HIDE);
			m_cmb4.ShowWindow(SW_HIDE);
			m_cmb5.ShowWindow(SW_SHOW);
			m_edt2.ShowWindow(SW_HIDE);
			m_edt3.ShowWindow(SW_SHOW);
		}
		else if(select==1){
			m_cmb3.ShowWindow(SW_SHOW);
			m_cmb4.ShowWindow(SW_SHOW);
			m_cmb5.ShowWindow(SW_HIDE);
			m_edt2.ShowWindow(SW_SHOW);
			m_edt3.ShowWindow(SW_HIDE);
		}
		else{
			m_cmb3.ShowWindow(SW_HIDE);
			m_cmb4.ShowWindow(SW_HIDE);
			m_cmb5.ShowWindow(SW_HIDE);
			m_edt2.ShowWindow(SW_HIDE);
			m_edt3.ShowWindow(SW_HIDE);
		}
		break;
	case SELECT_USEROPER:
		m_cmb1.ShowWindow(SW_HIDE);
		m_cmb2.ShowWindow(SW_HIDE);
		m_cmb3.ShowWindow(SW_HIDE);
		m_cmb4.ShowWindow(SW_HIDE);
		m_cmb5.ShowWindow(SW_HIDE);
		m_cmb6.ShowWindow(SW_SHOW);
		m_edt1.ShowWindow(SW_HIDE);
		m_edt2.ShowWindow(SW_HIDE);
		m_edt3.ShowWindow(SW_HIDE);
		m_edt4.ShowWindow(SW_HIDE);
		m_edt5.ShowWindow(SW_HIDE);
		m_Progress.ShowWindow(SW_HIDE);
		break;
	case CHANGE_USRPWD:
//	case REG_DEVICE:
		m_cmb1.ShowWindow(SW_HIDE);
		m_cmb2.ShowWindow(SW_HIDE);
		m_cmb3.ShowWindow(SW_HIDE);
		m_cmb4.ShowWindow(SW_HIDE);
		m_cmb5.ShowWindow(SW_HIDE);
		m_cmb6.ShowWindow(SW_HIDE);
		m_edt1.ShowWindow(SW_HIDE);
		m_edt2.ShowWindow(SW_HIDE);
		m_edt3.ShowWindow(SW_HIDE);
		m_Progress.ShowWindow(SW_HIDE);
		if(m_UserOper==0){
			if(m_FindWan==1){
				m_edt4.ShowWindow(SW_SHOW);
				m_edt5.ShowWindow(SW_SHOW);
			}
			else{
				m_edt4.ShowWindow(SW_HIDE);
				m_edt5.ShowWindow(SW_HIDE);
			}
		}
		else{
			if((m_FindWan==1)&&(m_FindReg==1)){
				m_edt4.ShowWindow(SW_SHOW);
				m_edt5.ShowWindow(SW_SHOW);
			}
			else{
				m_edt4.ShowWindow(SW_HIDE);
				m_edt5.ShowWindow(SW_HIDE);
			}
		}
		break;
	case FIN_OPER:
		m_cmb1.ShowWindow(SW_HIDE);
		m_cmb2.ShowWindow(SW_HIDE);
		m_cmb3.ShowWindow(SW_HIDE);
		m_cmb4.ShowWindow(SW_HIDE);
		m_cmb5.ShowWindow(SW_HIDE);
		m_cmb6.ShowWindow(SW_HIDE);
		m_edt1.ShowWindow(SW_HIDE);
		m_edt2.ShowWindow(SW_HIDE);
		m_edt3.ShowWindow(SW_HIDE);
		m_edt4.ShowWindow(SW_HIDE);
		m_edt5.ShowWindow(SW_HIDE);
		if(m_UserOper==1)
			m_Progress.ShowWindow(SW_SHOW);
		else
			m_Progress.ShowWindow(SW_HIDE);
		break;
	case SCAN_PC:
	case INTERFACE_INTRO:
	case CONNECT_NETLINE:
	case OPEN_POWER:
	case SCAN_GATEWAY:
	case SAVE_WIFIINFO:
	case WELCOME_USER:
	default :
		m_cmb1.ShowWindow(SW_HIDE);
		m_cmb2.ShowWindow(SW_HIDE);
		m_cmb3.ShowWindow(SW_HIDE);
		m_cmb4.ShowWindow(SW_HIDE);
		m_cmb5.ShowWindow(SW_HIDE);
		m_cmb6.ShowWindow(SW_HIDE);
		m_edt1.ShowWindow(SW_HIDE);
		m_edt2.ShowWindow(SW_HIDE);
		m_edt3.ShowWindow(SW_HIDE);
		m_edt4.ShowWindow(SW_HIDE);
		m_edt5.ShowWindow(SW_HIDE);
		m_Progress.ShowWindow(SW_HIDE);
		break;
	}
}

void CEHomeEIWrdDlg::ShowMenu(const OperStep _step, RECT &rect) 
{
	switch(_step)
	{
	case WELCOME_USER:
		m_MainDC->SetTextColor(COLOR_BLUE);
		rect.left = m_CfgFile.GetInt(APP_MENU, KEY_LEFT);
		rect.top = m_CfgFile.GetInt(APP_MENU, KEY_TOP);
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt1")), &rect,DT_LEFT);
		rect.top += m_MOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt2")), &rect,DT_LEFT);
		rect.top += m_MOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt3")), &rect,DT_LEFT);
		rect.top += m_MOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt4")), &rect,DT_LEFT);
		break;
	case SCAN_PC:
		m_MainDC->SetTextColor(COLOR_BLUE);
		rect.left = m_CfgFile.GetInt(APP_MENU, KEY_LEFT);
		rect.top = m_CfgFile.GetInt(APP_MENU, KEY_TOP);
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt1")), &rect,DT_LEFT);
		rect.top += m_MOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt2")), &rect,DT_LEFT);

		rect.top += m_MOffset;
		rect.left += m_MOffset;
		m_MainDC->SetTextColor(COLOR_BROWN);
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt2_1")), &rect,DT_LEFT);
		m_MainDC->SetTextColor(COLOR_GREEN);
		rect.top += m_SOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt2_2")), &rect,DT_LEFT);
		rect.top += m_SOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt2_3")), &rect,DT_LEFT);
		rect.top += m_SOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt2_4")), &rect,DT_LEFT);
		rect.top += m_SOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt2_5")), &rect,DT_LEFT);
		
		rect.left -= m_MOffset;
		m_MainDC->SetTextColor(COLOR_BLUE);
		rect.top += m_MOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt3")), &rect,DT_LEFT);
		rect.top += m_MOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt4")), &rect,DT_LEFT);
		break;
	case SELECT_GATEWAY:
		m_MainDC->SetTextColor(COLOR_BLUE);
		rect.left = m_CfgFile.GetInt(APP_MENU, KEY_LEFT);
		rect.top = m_CfgFile.GetInt(APP_MENU, KEY_TOP);
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt1")), &rect,DT_LEFT);
		rect.top += m_MOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt2")), &rect,DT_LEFT);

		rect.top += m_MOffset;
		rect.left += m_MOffset;
		m_MainDC->SetTextColor(COLOR_GREEN);
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt2_1")), &rect,DT_LEFT);
		m_MainDC->SetTextColor(COLOR_BROWN);
		rect.top += m_SOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt2_2")), &rect,DT_LEFT);
		m_MainDC->SetTextColor(COLOR_GREEN);
		rect.top += m_SOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt2_3")), &rect,DT_LEFT);
		rect.top += m_SOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt2_4")), &rect,DT_LEFT);
		rect.top += m_SOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt2_5")), &rect,DT_LEFT);
		
		rect.left -= m_MOffset;
		m_MainDC->SetTextColor(COLOR_BLUE);
		rect.top += m_MOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt3")), &rect,DT_LEFT);
		rect.top += m_MOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt4")), &rect,DT_LEFT);
		break;
	case INTERFACE_INTRO:
		m_MainDC->SetTextColor(COLOR_BLUE);
		rect.left = m_CfgFile.GetInt(APP_MENU, KEY_LEFT);
		rect.top = m_CfgFile.GetInt(APP_MENU, KEY_TOP);
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt1")), &rect,DT_LEFT);
		rect.top += m_MOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt2")), &rect,DT_LEFT);

		rect.top += m_MOffset;
		rect.left += m_MOffset;
		m_MainDC->SetTextColor(COLOR_GREEN);
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt2_1")), &rect,DT_LEFT);
		rect.top += m_SOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt2_2")), &rect,DT_LEFT);
		m_MainDC->SetTextColor(COLOR_BROWN);
		rect.top += m_SOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt2_3")), &rect,DT_LEFT);
		m_MainDC->SetTextColor(COLOR_GREEN);
		rect.top += m_SOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt2_4")), &rect,DT_LEFT);
		rect.top += m_SOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt2_5")), &rect,DT_LEFT);
		
		rect.left -= m_MOffset;
		m_MainDC->SetTextColor(COLOR_BLUE);
		rect.top += m_MOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt3")), &rect,DT_LEFT);
		rect.top += m_MOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt4")), &rect,DT_LEFT);
		break;
	case CONNECT_NETLINE:
		m_MainDC->SetTextColor(COLOR_BLUE);
		rect.left = m_CfgFile.GetInt(APP_MENU, KEY_LEFT);
		rect.top = m_CfgFile.GetInt(APP_MENU, KEY_TOP);
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt1")), &rect,DT_LEFT);
		rect.top += m_MOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt2")), &rect,DT_LEFT);

		rect.top += m_MOffset;
		rect.left += m_MOffset;
		m_MainDC->SetTextColor(COLOR_GREEN);
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt2_1")), &rect,DT_LEFT);
		rect.top += m_SOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt2_2")), &rect,DT_LEFT);
		rect.top += m_SOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt2_3")), &rect,DT_LEFT);
		m_MainDC->SetTextColor(COLOR_BROWN);
		rect.top += m_SOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt2_4")), &rect,DT_LEFT);
		m_MainDC->SetTextColor(COLOR_GREEN);
		rect.top += m_SOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt2_5")), &rect,DT_LEFT);
		
		rect.left -= m_MOffset;
		m_MainDC->SetTextColor(COLOR_BLUE);
		rect.top += m_MOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt3")), &rect,DT_LEFT);
		rect.top += m_MOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt4")), &rect,DT_LEFT);
		break;
	case OPEN_POWER:
		m_MainDC->SetTextColor(COLOR_BLUE);
		rect.left = m_CfgFile.GetInt(APP_MENU, KEY_LEFT);
		rect.top = m_CfgFile.GetInt(APP_MENU, KEY_TOP);
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt1")), &rect,DT_LEFT);
		rect.top += m_MOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt2")), &rect,DT_LEFT);

		rect.top += m_MOffset;
		rect.left += m_MOffset;
		m_MainDC->SetTextColor(COLOR_GREEN);
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt2_1")), &rect,DT_LEFT);
		rect.top += m_SOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt2_2")), &rect,DT_LEFT);
		rect.top += m_SOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt2_3")), &rect,DT_LEFT);
		rect.top += m_SOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt2_4")), &rect,DT_LEFT);
		rect.top += m_SOffset;
		m_MainDC->SetTextColor(COLOR_BROWN);
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt2_5")), &rect,DT_LEFT);
		
		rect.left -= m_MOffset;
		m_MainDC->SetTextColor(COLOR_BLUE);
		rect.top += m_MOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt3")), &rect,DT_LEFT);
		rect.top += m_MOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt4")), &rect,DT_LEFT);
		break;
	case SCAN_GATEWAY:
		m_MainDC->SetTextColor(COLOR_BLUE);
		rect.left = m_CfgFile.GetInt(APP_MENU, KEY_LEFT);
		rect.top = m_CfgFile.GetInt(APP_MENU, KEY_TOP);
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt1")), &rect,DT_LEFT);
		rect.top += m_MOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt2")), &rect,DT_LEFT);
		rect.top += m_MOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt3")), &rect,DT_LEFT);

		rect.top += m_MOffset;
		rect.left += m_MOffset;
		m_MainDC->SetTextColor(COLOR_BROWN);
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt3_1")) + _T(" ") + m_GatewayName, &rect,DT_LEFT);
		m_MainDC->SetTextColor(COLOR_GREEN);
		rect.top += m_SOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt3_2")), &rect,DT_LEFT);
		rect.top += m_SOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt3_3")), &rect,DT_LEFT);	
		rect.left -= m_MOffset;

		m_MainDC->SetTextColor(COLOR_BLUE);
		rect.top += m_MOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt4")), &rect,DT_LEFT);
		break;
	case INPUT_WIFIINFO:
		m_MainDC->SetTextColor(COLOR_BLUE);
		rect.left = m_CfgFile.GetInt(APP_MENU, KEY_LEFT);
		rect.top = m_CfgFile.GetInt(APP_MENU, KEY_TOP);
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt1")), &rect,DT_LEFT);
		rect.top += m_MOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt2")), &rect,DT_LEFT);
		rect.top += m_MOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt3")), &rect,DT_LEFT);

		rect.top += m_MOffset;
		rect.left += m_MOffset;
		m_MainDC->SetTextColor(COLOR_GREEN);
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt3_1")) + _T(" ") + m_GatewayName, &rect,DT_LEFT);
		m_MainDC->SetTextColor(COLOR_BROWN);
		rect.top += m_SOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt3_2")), &rect,DT_LEFT);
		m_MainDC->SetTextColor(COLOR_GREEN);
		rect.top += m_SOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt3_3")), &rect,DT_LEFT);	
		rect.left -= m_MOffset;

		m_MainDC->SetTextColor(COLOR_BLUE);
		rect.top += m_MOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt4")), &rect,DT_LEFT);
		break;
	case SAVE_WIFIINFO:
		m_MainDC->SetTextColor(COLOR_BLUE);
		rect.left = m_CfgFile.GetInt(APP_MENU, KEY_LEFT);
		rect.top = m_CfgFile.GetInt(APP_MENU, KEY_TOP);
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt1")), &rect,DT_LEFT);
		rect.top += m_MOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt2")), &rect,DT_LEFT);
		rect.top += m_MOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt3")), &rect,DT_LEFT);

		rect.top += m_MOffset;
		rect.left += m_MOffset;
		m_MainDC->SetTextColor(COLOR_GREEN);
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt3_1")) + _T(" ") + m_GatewayName, &rect,DT_LEFT);
		rect.top += m_SOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt3_2")), &rect,DT_LEFT);
		rect.top += m_SOffset;
		m_MainDC->SetTextColor(COLOR_BROWN);
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt3_3")), &rect,DT_LEFT);	
		rect.left -= m_MOffset;

		m_MainDC->SetTextColor(COLOR_BLUE);
		rect.top += m_MOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt4")), &rect,DT_LEFT);
		break;
	case SELECT_USEROPER:
		m_MainDC->SetTextColor(COLOR_BLUE);
		rect.left = m_CfgFile.GetInt(APP_MENU, KEY_LEFT);
		rect.top = m_CfgFile.GetInt(APP_MENU, KEY_TOP);
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt1")), &rect,DT_LEFT);
		rect.top += m_MOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt2")), &rect,DT_LEFT);
		rect.top += m_MOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt3")), &rect,DT_LEFT);
		rect.top += m_MOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt4")), &rect,DT_LEFT);

		rect.top += m_MOffset;
		rect.left += m_MOffset;
		m_MainDC->SetTextColor(COLOR_BROWN);
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt4_1")), &rect,DT_LEFT);
		rect.top += m_SOffset;
		m_MainDC->SetTextColor(COLOR_GREEN);
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt4_2")), &rect,DT_LEFT);
		break;
	case CHANGE_USRPWD:
//	case REG_DEVICE:
	case FIN_OPER:
		m_MainDC->SetTextColor(COLOR_BLUE);
		rect.left = m_CfgFile.GetInt(APP_MENU, KEY_LEFT);
		rect.top = m_CfgFile.GetInt(APP_MENU, KEY_TOP);
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt1")), &rect,DT_LEFT);
		rect.top += m_MOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt2")), &rect,DT_LEFT);
		rect.top += m_MOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt3")), &rect,DT_LEFT);
		rect.top += m_MOffset;
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt4")), &rect,DT_LEFT);

		rect.top += m_MOffset;
		rect.left += m_MOffset;
		m_MainDC->SetTextColor(COLOR_GREEN);
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt4_1")), &rect,DT_LEFT);
		rect.top += m_SOffset;
		m_MainDC->SetTextColor(COLOR_BROWN);
		m_MainDC->DrawText(m_CfgFile.GetString(APP_MENU, _T("Txt4_2")), &rect,DT_LEFT);
		break;
	default :
		break;
	}
}

void CEHomeEIWrdDlg::OnButtonPre() 
{
	// TODO: Add your control notification handler code here
	m_btnPre.EnableWindow(false);//disable previous button
	m_Step=(OperStep)(m_Step-1);

	if(m_Step==CHANGE_USRPWD){
		if(m_UserOper==0){//�û�����ѡ���������
			if(!m_SavedPppName.IsEmpty()){
				m_edt4.SetWindowText(m_SavedPppName);
				m_edt5.SetWindowText(m_SavedPppPassword);
			}
		}
		else{
			if(!m_SavedRegName.IsEmpty()){
				m_edt4.SetWindowText(m_SavedRegName);
				m_edt5.SetWindowText(m_SavedRegPassword);
			}
		}
	}

	if(m_Step==SCAN_GATEWAY){
		m_btnCancel.SetWindowText(m_CfgFile.GetString(APP_SCAN_GATEWAY, _T("Txt5")));
	}
	if(m_Step==FIN_OPER){
		m_btnCancel.SetWindowText(m_CfgFile.GetString(APP_FIN_OPER, _T("Txt2")));
	}

	Invalidate(false);
	OnPaint();

	SetTimer(TIMER_UNLOCK, TIMER_INTERVAL_UNLOCK, NULL);
}

void CEHomeEIWrdDlg::OnButtonNext() 
{
	// TODO: Add your control notification handler code here
	
	CString pingStr;

	//http
	CHttpSocket HttpSocket;
	CString strServer,strObject;
	unsigned short nPort;
	DWORD dwServiceType;
	long nLength;
	const char *pRequestHeader = NULL;
	CString url;

	int nLineSize = 0;
	int nHit = 0;
	char szLine[256];

	if((m_Step==SELECT_USEROPER)&&(m_Locked_CHANGE_USRPWD==1))
		return;

	m_btnNext.EnableWindow(false);//disable next button

	if(m_UserSave&0x3){//both save
	}

	if(m_Step==FIN_OPER)
		m_Step = SAVE_WIFIINFO;

	m_Step=(OperStep)(m_Step+1);

	if((m_Step > SELECT_GATEWAY)&&(m_Step < SCAN_GATEWAY)){
		pingStr.Format(_T("cmd.exe /c ping %s"),m_SvrHost);
		WinExec(pingStr, SW_HIDE);
	}

	m_btnCancel.SetWindowText(m_CfgFile.GetString(APP_CAPTION, _T("Cancel")));

	if(m_Step==SCAN_GATEWAY){

		BeginWaitCursor(); // display the hourglass cursor 
		
		url = HTTP_PREFIX+m_SvrHost+m_CfgFile.GetString(APP_MODEMCFG, _T("Url1"));
		AfxParseURL(url,dwServiceType,strServer,strObject,nPort);
		//ͨ��http���ָ����url
		pRequestHeader = HttpSocket.FormatRequestHeader((LPTSTR)(LPCTSTR)strServer,(LPTSTR)(LPCTSTR)strObject,nLength);	
		HttpSocket.Socket();
		HttpSocket.Connect((LPTSTR)(LPCTSTR)strServer);
		HttpSocket.SetTimeout(HTTP_TIMEOUT,0);
		HttpSocket.SendRequest();

		#ifdef _DEBUG
		m_Info.InsertString(m_Info.GetCount(),pRequestHeader);
		#endif
		//����
		while(nLineSize != -1)
		{
			nLineSize = HttpSocket.GetResponseLine(szLine,256);
			if(nLineSize > -1)
			{
				szLine[nLineSize] = '\0';
				#ifdef _DEBUG
				m_Info.InsertString(m_Info.GetCount(),szLine);
				#endif
				CString line;
				line.Format(_T("%s"),szLine);
				if(nHit==1){
					m_RemoteGatewayName=line.Left(line.GetLength()-5);//gateway name
					if(m_RemoteGatewayName!=m_GatewayName)
						m_ScanResult = 0;
					else
						m_ScanResult = 1;
					nHit++;
				}
				else if(nHit==2){
					m_UID=line.Left(line.GetLength()-5);//uid
					nHit++;
				}
				else if(nHit==3){
					m_PSW=line.Left(line.GetLength()-5);//psw
					nHit++;
				}
				else if(nHit==4){
					if(line.Left(line.GetLength()-1).Find(_T("Yes"))>=0)//TelnetActive
						m_TelnetActive=1;
					else
						m_TelnetActive=0;
					nHit=0;
				}
				if(line.Find(HTTP_HEAD_END)>=0)
					nHit=1;
			}
		}
		m_btnOK.SetWindowText(m_CfgFile.GetString(APP_SCAN_GATEWAY, _T("Txt4")));
		m_btnCancel.SetWindowText(m_CfgFile.GetString(APP_SCAN_GATEWAY, _T("Txt5")));

		EndWaitCursor(); // remove the hourglass cursor 
	}
	else if(m_Step==INPUT_WIFIINFO){
		if(m_TelnetConnected==0)
			m_pSocket->Connect(m_SvrHost, m_SvrPort);//����telnet��������
		m_btnOK.SetWindowText(m_CfgFile.GetString(APP_INPUT_WIFIINFO, _T("Txt9")));
	}
	else if(m_Step==CHANGE_USRPWD){
		if((m_SkipWLan==1)&&(m_TelnetConnected==0)){//�Ƿ�����wlan����
			m_pSocket->Connect(m_SvrHost, m_SvrPort);//����telnet��������
		}
		else{
			if(m_UserOper==0){
				DispatchMessage(_T("tcapi get WanInfo_Common CycleNum\r\n"));
			}
			else{
				DispatchMessage(_T("tcapi get WanInfo_Common CycleNum\r\n"));
			}
			m_Connected=9;
		}

		if(m_UserOper==0){//�û�����ѡ���������
			m_btnOK.SetWindowText(m_CfgFile.GetString(APP_CHANGE_USRPWD, _T("Txt4")));
		}
		else{
			m_btnOK.SetWindowText(m_CfgFile.GetString(APP_REG_DEVICE, _T("Txt4")));
		}
		//Ϊ1��ʾ���û�ѡ���޸�����/�豸ע�ᣬ�����һ����telnet�����������Ϣ�����������ؼ����ʴ�ǰ�������һ����Ч
		m_Locked_CHANGE_USRPWD = 1;
		m_Step=(OperStep)(m_Step-1);
	}
	else if(m_Step==FIN_OPER){
		m_btnCancel.SetWindowText(m_CfgFile.GetString(APP_FIN_OPER, _T("Txt2")));
	}

	Invalidate(false);
	OnPaint();

	SetTimer(TIMER_UNLOCK, TIMER_INTERVAL_UNLOCK, NULL);
}

void CEHomeEIWrdDlg::OnButtonClose() 
{
	// TODO: Add your control notification handler code here
	int iMsg = AfxMessageBox(m_CfgFile.GetString(APP_ERR_MSG, _T("Err0")), MB_YESNO|MB_ICONQUESTION);
	if (iMsg == IDYES)
	{
		CDialog::OnOK();
	}
	Invalidate(false);
	OnPaint();
}

void CEHomeEIWrdDlg::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default

	//start button
	if(m_Step == WELCOME_USER)//��ҳ�Ͽ�ʼ��ťЧ��
	{
		HBITMAP	hbmp;
		if((point.x > m_SBtnLeft) && (point.x < m_SBtnLeft + START_BUTTON_WIDTH)
			&& (point.y > m_SBtnTop) && (point.y < m_SBtnTop + START_BUTTON_HEIGHT))
			hbmp = (HBITMAP)LoadImage(NULL, _T("res\\start_on.bmp"), IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
		else
			hbmp = (HBITMAP)LoadImage(NULL, _T("res\\start_off.bmp"), IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
		if(hbmp != NULL)
		{		
			SelectObject(m_hdcBmp, hbmp);
			TransparentBlt(m_MainDC->m_hDC,m_SBtnLeft,m_SBtnTop,START_BUTTON_WIDTH,START_BUTTON_HEIGHT,
							m_hdcBmp,0,0,START_BUTTON_WIDTH,START_BUTTON_HEIGHT,COLOR_WHITE);
			DeleteObject(hbmp);
		}
	}
	CDialog::OnMouseMove(nFlags, point);
}

void CEHomeEIWrdDlg::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if((m_Step == WELCOME_USER)
		&& (point.x > m_SBtnLeft) && (point.x < m_SBtnLeft + START_BUTTON_WIDTH)
		&& (point.y > m_SBtnTop) && (point.y < m_SBtnTop + START_BUTTON_HEIGHT))
		OnButtonNext();
	
	CDialog::OnLButtonUp(nFlags, point);
}

//telnet�ظ���Ϣ
void CEHomeEIWrdDlg::ProcessMessage(CClientSocket *cSocket)
{
	CString inputStr;
	CString	queryStr;
	CString setStr;
	int splitCount=0;
	int i=0;
	int pos=0;
	int nBytes = m_pSocket->Receive(m_bBuf.GetData(),m_bBuf.GetSize());

	if(nBytes != SOCKET_ERROR)
	{
		int ndx = 0;
		while(GetLine(m_bBuf, nBytes, ndx) != TRUE);

		ProcessOptions();
		#ifdef _DEBUG
		m_Info.InsertString(m_Info.GetCount(),m_strNormalText);
		int ix=0;
		while(ix<m_strNormalText.GetLength()){
			char ch = m_strNormalText.GetAt(ix);
			ix++;
		}
		#endif
		
		//error
		if(m_strNormalText.Find(_T("Local administrator is configuring this device now"))>=0){
			SocketError();
		}		

		//auto response
		if(m_strNormalText == _T("tc login: ")){
			DispatchMessage(m_UID+_T("\r\n"));
		}
		else if(m_strNormalText.Find(_T("\r\nPassword: "))>=0){
			DispatchMessage(m_PSW+_T("\r\n"));
			m_Connected=1;
			m_TelnetConnected=1;
		}		
		else if((m_strNormalText == _T("# ")) && (m_Connected==1)){//normal
			if(m_SkipWLan==1){
				m_SkipWLan=0;
				if(m_UserOper==0){//�û�����ѡ���������
					DispatchMessage(_T("tcapi get WanInfo_Common CycleNum\r\n"));
				}
				else{
					DispatchMessage(_T("tcapi get WanInfo_Common CycleNum\r\n"));
				}
				m_Connected=9;
			}
			else{
				DispatchMessage(_T("tcapi get WLan_Entry0 SSID\r\n"));
				m_Connected++;
			}
		}
		else if(m_strNormalText.Right(2) == _T("# ")){
			if(m_Locked==1){//save ok
				m_edt4.SetWindowText(_T(""));
				m_edt5.SetWindowText(_T(""));

				m_Locked=0;
				OnButtonNext();
				EndWaitCursor();
				ReleaseCapture();

				if(m_Step==FIN_OPER){
					if(m_UserOper==1){//reg
						DispatchMessage(_T("tcapi get deviceAccount_Entry retryLimit\r\n"));
						m_Connected=19;
						SetTimer(TIMER_REG,TIMER_INTERVAL,NULL);
					}
				}
			}

			if(m_Connected==2){
				pos=m_strNormalText.Find(m_SSIDPrefix);
				if(pos>=0)
					m_edt1.SetWindowText(m_strNormalText.Mid(pos+m_SSIDPrefix.GetLength(),m_strNormalText.GetLength()-pos-m_SSIDPrefix.GetLength()-LR_WIN));
				DispatchMessage(_T("tcapi get WLan_Entry0 AuthMode\r\n"));

				m_Connected++;
			}
			else if(m_Connected==3){
				if(m_strNormalText.Find(_T("WPA"))>=0){
					m_cmb2.SetCurSel(2);
					DispatchMessage(_T("tcapi get WLan_Entry0 WPAPSK\r\n"));
				}				
				else if(m_strNormalText.Find(_T("WEP-"))>=0){
					m_cmb2.SetCurSel(1);
					if(m_strNormalText.Find(_T("128Bits"))>=0)
						m_cmb3.SetCurSel(1);
					else
						m_cmb3.SetCurSel(0);
					DispatchMessage(_T("tcapi get WLan_Entry0 DefaultKeyID\r\n"));
				}
				else{
					m_cmb2.SetCurSel(0);
					m_cmb3.SetCurSel(0);
					m_cmb4.SetCurSel(0);
					m_cmb5.SetCurSel(0);
				}

				Invalidate(false);
				OnPaint();

				m_Connected++;
			}
			else if(m_Connected==4){
				if(m_cmb2.GetCurSel()>=2){//wpa key
					setStr=m_strNormalText.Left(m_strNormalText.GetLength()-LR_WIN);
					pos=setStr.Find(_T("\r\n"));
					if(pos>=0){
						m_edt3.SetWindowText(setStr.Mid(pos+2,setStr.GetLength()-pos-2));
					}
					else
						m_edt3.SetWindowText(setStr);
					DispatchMessage(_T("tcapi get WLan_Entry0 EncrypType\r\n"));
					m_cmb3.SetCurSel(0);
					m_cmb4.SetCurSel(0);
				}
				else if(m_cmb2.GetCurSel()==1)
				{
					if(m_strNormalText.Find(_T("4"))>=0){
						m_cmb4.SetCurSel(3);
						DispatchMessage(_T("tcapi get WLan_Entry0 Key4Str\r\n"));
					}
					else if(m_strNormalText.Find(_T("3"))>=0){
						m_cmb4.SetCurSel(2);
						DispatchMessage(_T("tcapi get WLan_Entry0 Key3Str\r\n"));
					}
					else if(m_strNormalText.Find(_T("2"))>=0){
						m_cmb4.SetCurSel(1);
						DispatchMessage(_T("tcapi get WLan_Entry0 Key2Str\r\n"));
					}
					else{
						m_cmb4.SetCurSel(0);
						DispatchMessage(_T("tcapi get WLan_Entry0 Key1Str\r\n"));
					}
					m_cmb5.SetCurSel(0);
				}
				else{
				}

				m_Connected++;
			}
			else if(m_Connected==5){
				if(m_cmb2.GetCurSel()>=2){
					if(m_strNormalText.Find(_T("TKIPAES"))>=0){
						m_cmb5.SetCurSel(2);
					}
					else if(m_strNormalText.Find(_T("TKIP"))>=0){
						m_cmb5.SetCurSel(1);
					}
					else
						m_cmb5.SetCurSel(0);
				}
				else if(m_cmb2.GetCurSel()==1)//wep key
				{
					setStr=m_strNormalText.Left(m_strNormalText.GetLength()-LR_WIN);
					pos=setStr.Find(_T("\r\n"));					
					if(pos>=0){
						m_edt2.SetWindowText(setStr.Mid(pos+2,setStr.GetLength()-pos-2));
					}
					else
						m_edt2.SetWindowText(setStr);
				}
				else{
				}

				m_Connected++;
			}
			else if(m_Connected==9){//pre-wan
				if(m_UserOper==0){
					DispatchMessage(_T("tcapi get WanInfo_Common CycleValue\r\n"));
				}
				else{
					DispatchMessage(_T("tcapi get WanInfo_Common CycleValue\r\n"));
				}

				m_Connected++;
			}
			else if(m_Connected==10){//Find Wan--GUIInterfaceName
				if(m_UserOper==0){//�û�����ѡ���������
					pos=m_strNormalText.Find(KEY_WAN);//INTERNET_R
					if(pos>=0){
						m_FindWan=1;
						
						setStr=m_strNormalText.Left(m_strNormalText.GetLength()-LR_WIN);
						pos=setStr.Find(_T("\r\n"));
						if(pos>=0){
							inputStr=setStr.Mid(pos+2,setStr.GetLength()-pos-2);
						}
						else
							inputStr=setStr;

						splitCount = SplitString(inputStr, KEY_SPLIT, m_StrArrGUIName);
						for(i=0;i<splitCount;i++){
							pos=m_StrArrGUIName[i].Find(KEY_WAN);
							if(pos>=0){
								m_ArrIndex=i;
								break;
							}
						}
						if(i>=splitCount)
							m_ArrIndex=0;

						DispatchMessage(_T("tcapi get WanInfo_Common CycleValue\r\n"));
					}
					else{
						m_FindWan=0;
						m_Locked_CHANGE_USRPWD=0;
						m_btnOK.SetWindowText(m_CfgFile.GetString(APP_CHANGE_USRPWD, _T("Txt6")));
						m_Step=(OperStep)(m_Step+1);
						Invalidate(false);
						OnPaint();
					}
				}
				else{//reg
					pos=m_strNormalText.Find(KEY_WAN);
					//if(pos>=0){//unlock the limit
					if(1){
						m_FindWan=1;
						DispatchMessage(_T("tcapi get Info_Adsl lineState\r\n"));
					}
					else{
						m_FindWan=0;
						m_Locked_CHANGE_USRPWD=0;
						m_btnOK.SetWindowText(m_CfgFile.GetString(APP_REG_DEVICE, _T("Txt6")));
						m_Step=(OperStep)(m_Step+1);
						Invalidate(false);
						OnPaint();
					}						
				}

				m_Connected++;
			}
			else if(m_Connected==11){
				if(m_UserOper==0){//�û�����ѡ���������
					DispatchMessage(_T("tcapi get WanInfo_Common CycleValue\r\n"));
				}
				else{//reg
					pos=m_strNormalText.Find(_T("up"));//wan adsl state
					if(pos>=0){
						m_FindReg=1;
						DispatchMessage(_T("tcapi get Cwmp_Entry webpageFlag\r\n"));
					}
					else{
						m_FindReg=0;
						m_Locked_CHANGE_USRPWD=0;
						m_btnOK.SetWindowText(m_CfgFile.GetString(APP_REG_DEVICE, _T("Txt6")));
						m_Step=(OperStep)(m_Step+1);
						Invalidate(false);
						OnPaint();
					}
				}

				m_Connected++;
			}
			else if(m_Connected==12){
				if(m_UserOper==0){//�û�����ѡ���������
					setStr=m_strNormalText.Left(m_strNormalText.GetLength()-LR_WIN);
					pos=setStr.Find(_T("\r\n"));
					if(pos>=0){
						inputStr=setStr.Mid(pos+2,setStr.GetLength()-pos-2);
					}
					else
						inputStr=setStr;

					splitCount = SplitString(inputStr, KEY_SPLIT, m_StrArrEntryIndex);
					m_WanEntryIndex=atoi(m_StrArrEntryIndex[m_ArrIndex]);
					queryStr.Format(_T("tcapi get Wan_PVC%d_Entry%d LinkMode\r\n"),m_WanEntryIndex/8,m_WanEntryIndex%8);					
					DispatchMessage(queryStr);
				}
				else{//reg
					if(m_FindReg==1){
						pos=m_strNormalText.Find(_T("1"));//webpageFlag
						if(pos>=0){
							m_FindReg=1;
							queryStr.Format(_T("tcapi get deviceAccount_Entry userName\r\n"));
							DispatchMessage(queryStr);
						}
						else{
							m_FindReg=0;
							m_Locked_CHANGE_USRPWD=0;
							m_btnOK.SetWindowText(m_CfgFile.GetString(APP_REG_DEVICE, _T("Txt6")));
							m_Step=(OperStep)(m_Step+1);
							Invalidate(false);
							OnPaint();
						}
					}
				}

				m_Connected++;
			}
			else if(m_Connected==13){
				if(m_UserOper==0){//judge ppp mode
					setStr=m_strNormalText.Left(m_strNormalText.GetLength()-LR_WIN);
					pos=setStr.Find(_T("\r\n"));
					if(pos>=0){
						inputStr=setStr.Mid(pos+2,setStr.GetLength()-pos-2);
					}
					else
						inputStr=setStr;

					if(inputStr.Find(_T("linkPPP"))>=0){
						queryStr.Format(_T("tcapi get Wan_PVC%d_Entry%d USERNAME\r\n"),m_WanEntryIndex/8,m_WanEntryIndex%8);
						DispatchMessage(queryStr);
					}
					else{
						m_FindWan=0;
						m_Locked_CHANGE_USRPWD=0;
						m_btnOK.SetWindowText(m_CfgFile.GetString(APP_CHANGE_USRPWD, _T("Txt6")));
						m_Step=(OperStep)(m_Step+1);
						Invalidate(false);
						OnPaint();
					}
				}
				else{//reg
					setStr=m_strNormalText.Left(m_strNormalText.GetLength()-LR_WIN);
					pos=setStr.Find(_T("\r\n"));
					if(pos>=0){
						inputStr=setStr.Mid(pos+2,setStr.GetLength()-pos-2);
					}
					else
						//inputStr=setStr;
						inputStr=_T("");
					m_edt4.SetWindowText(inputStr);
	
					queryStr.Format(_T("tcapi get deviceAccount_Entry userPasswordDEV\r\n"));
					DispatchMessage(queryStr);
				}

				m_Connected++;
			}
			else if(m_Connected==14){
				if(m_UserOper==0){//set ppp username to control
					setStr=m_strNormalText.Left(m_strNormalText.GetLength()-LR_WIN);
					pos=setStr.Find(_T("\r\n"));
					if(pos>=0){
						inputStr=setStr.Mid(pos+2,setStr.GetLength()-pos-2);
					}
					else
						inputStr=_T("");
					m_edt4.SetWindowText(inputStr);
	
					queryStr.Format(_T("tcapi get Wan_PVC%d_Entry%d PASSWORD\r\n"),m_WanEntryIndex/8,m_WanEntryIndex%8);
					DispatchMessage(queryStr);
				}				
				else{//reg
					setStr=m_strNormalText.Left(m_strNormalText.GetLength()-LR_WIN);
					pos=setStr.Find(_T("\r\n"));
					if(pos>=0){
						inputStr=setStr.Mid(pos+2,setStr.GetLength()-pos-2);
					}
					else
						//inputStr=setStr;
						inputStr=_T("");
					m_edt5.SetWindowText(inputStr);

					queryStr.Format(_T("tcapi get deviceAccount_Entry registerStatus\r\n"));
					DispatchMessage(queryStr);
				}

				m_Connected++;
			}
			else if(m_Connected==15){
				if(m_UserOper==0){//set ppp password to control
					setStr=m_strNormalText.Left(m_strNormalText.GetLength()-LR_WIN);
					pos=setStr.Find(_T("\r\n"));
					if(pos>=0){
						inputStr=setStr.Mid(pos+2,setStr.GetLength()-pos-2);
					}
					else
						inputStr=setStr;
					m_edt5.SetWindowText(inputStr);
				}
				else{//reg
					setStr=m_strNormalText.Left(m_strNormalText.GetLength()-LR_WIN);
					pos=setStr.Find(_T("\r\n"));
					//m_init_registerStatus will be set when m_Connected=22
					/*
					if(pos>=0){
						m_init_registerStatus=atoi(setStr.Mid(pos+2,setStr.GetLength()-pos-2));
					}
					else
						m_init_registerStatus=atoi(setStr);
					*/

				}

				m_Step=(OperStep)(m_Step+1);
				Invalidate(false);
				OnPaint();
				m_Locked_CHANGE_USRPWD = 0;//unlock:telnet��Ϣ������ɣ������¸�step

				m_Connected++;
			}
			else if(m_Connected==19){//pre-reg
				m_Connected++;
			}
			else if(m_Connected==20){//reg
				setStr=m_strNormalText.Left(m_strNormalText.GetLength()-LR_WIN);
				//when call spsave,it will use up time ,so the response message will delay
				//the reply message maybe is reponse to spsave
				if(setStr.Find("retryLimit")>=0){
					pos=setStr.Find(_T("\r\n"));
					if(pos>=0){
						m_retryLimit=atoi(setStr.Mid(pos+2,setStr.GetLength()-pos-2));
					}
					else
						m_retryLimit=atoi(setStr);
		
					DispatchMessage(_T("tcapi get deviceAccount_Entry retryTimes\r\n"));

					m_Connected++;				
				}
			}
			else if(m_Connected==21){
				setStr=m_strNormalText.Left(m_strNormalText.GetLength()-LR_WIN);
				pos=setStr.Find(_T("\r\n"));
				if(pos>=0){
					m_retryTimes=atoi(setStr.Mid(pos+2,setStr.GetLength()-pos-2));
				}
				else
					m_retryTimes=atoi(setStr);
				
				DispatchMessage(_T("tcapi get deviceAccount_Entry registerStatus\r\n"));

				m_Connected++;
			}
			else if(m_Connected==22){
				setStr=m_strNormalText.Left(m_strNormalText.GetLength()-LR_WIN);
				pos=setStr.Find(_T("\r\n"));
				if(pos>=0){
					m_registerStatus=atoi(setStr.Mid(pos+2,setStr.GetLength()-pos-2));
				}
				else
					m_registerStatus=atoi(setStr);
				
				if(m_init_reg==1){
					m_init_registerStatus=m_registerStatus;
					//m_init_registerStatus=99;//merge from ct web
				}
				if(m_registerStatus!=m_init_registerStatus)
					m_init_Changed=1;

				DispatchMessage(_T("tcapi get deviceAccount_Entry registerResult\r\n"));

				m_Connected++;
			}
			else if(m_Connected==23){
				setStr=m_strNormalText.Left(m_strNormalText.GetLength()-LR_WIN);
				pos=setStr.Find(_T("\r\n"));
				if(pos>=0){
					m_registerResult=atoi(setStr.Mid(pos+2,setStr.GetLength()-pos-2));
				}
				else
					m_registerResult=atoi(setStr);

				if(m_init_reg==1){
					m_init_reg=0;
					m_init_registerResult=m_registerResult;
					//m_init_registerResult=99;//merge from ct web
				}
				if(m_registerResult!=m_init_registerResult)
					m_init_Changed=1;
				
				GetMsg();//call this function to calculate the m_tryTimesflg
				if(m_tryTimesflg==1){
					CString setStr;
					setStr.Format(_T("tcapi set deviceAccount_Entry retryTimes %d\r\ntcapi commit deviceAccount_Entry\r\n"),m_retryTimes+1);
					DispatchMessage(setStr);
				}

				m_TimeOutCnt++;

				m_Connected++;
			}						
		}
	}
	else{//socket error
		SocketError();
	}
	m_strLine.Empty();
	m_strResp.Empty();
}

BOOL CEHomeEIWrdDlg::GetLine(const CByteArray &bytes, int nBytes, int &ndx)
{
	BOOL bLine = FALSE;
	while ( bLine == FALSE && ndx < nBytes )
	{
		unsigned char ch = (char)(bytes.GetAt( ndx ));
		
		switch( ch )
		{
		case '\r': // ignore
			m_strLine += "\r\n"; //"CR";
			break;
		case '\n': // end-of-line
			break;
		default:   // other....
			m_strLine += ch;
			break;
		} 

		++ndx;

		if (ndx == nBytes)
		{
			bLine = TRUE;
		}
	}
	return bLine;
}

void CEHomeEIWrdDlg::ProcessOptions()
{
	CString m_strTemp;
	CString m_strOption;
	unsigned char ch;
	int ndx;
	int ldx;
	BOOL bScanDone = FALSE;

	m_strTemp = m_strLine;

	while(!m_strTemp.IsEmpty() && bScanDone != TRUE)
	{
		ndx = m_strTemp.Find(IAC);
		if(ndx != -1)
		{
			m_strNormalText += m_strTemp.Left(ndx);
			ch = m_strTemp.GetAt(ndx + 1);
			switch(ch)
			{
			case DO:
			case DONT:
			case WILL:
			case WONT:
				m_strOption		= m_strTemp.Mid(ndx, 3);
				m_strTemp		= m_strTemp.Mid(ndx + 3);
				m_strNormalText	= m_strTemp.Left(ndx);
				m_ListOptions.AddTail(m_strOption);
				break;
			case IAC:
				m_strNormalText	= m_strTemp.Left(ndx);
				m_strTemp		= m_strTemp.Mid(ndx + 1);
				break;
			case SB:
				m_strNormalText = m_strTemp.Left(ndx);
				ldx = m_strTemp.Find(SE);
				m_strOption		= m_strTemp.Mid(ndx, ldx);
				m_ListOptions.AddTail(m_strOption);
				m_strTemp		= m_strTemp.Mid(ldx);
				AfxMessageBox(m_strOption,MB_OK);
				break;
			}
		}
		else
		{
			m_strNormalText = m_strTemp;
			bScanDone = TRUE;
		}
	} 
	
	RespondToOptions();

}

void CEHomeEIWrdDlg::RespondToOptions()
{
	CString strOption;
	
	while(!m_ListOptions.IsEmpty())
	{
		strOption = m_ListOptions.RemoveHead();

		ArrangeReply(strOption);
	}

	DispatchMessage(m_strResp);
	m_strResp.Empty();
}

void CEHomeEIWrdDlg::ArrangeReply(CString strOption)
{
	unsigned char Verb;
	unsigned char Option;
	unsigned char Modifier;
	unsigned char ch;
	BOOL bDefined = FALSE;

	Verb = strOption.GetAt(1);
	Option = strOption.GetAt(2);

	switch(Option)
	{
	case 1:	// Echo
	case 3: // Suppress Go-Ahead
		bDefined = TRUE;
		break;
	}

	m_strResp += IAC;

	if(bDefined == TRUE)
	{
		switch(Verb)
		{
		case DO:
			ch = WILL;
			m_strResp += ch;
			m_strResp += Option;
			break;
		case DONT:
			ch = WONT;
			m_strResp += ch;
			m_strResp += Option;
			break;
		case WILL:
			ch = DO;
			m_strResp += ch;
			m_strResp += Option;
			break;
		case WONT:
			ch = DONT;
			m_strResp += ch;
			m_strResp += Option;
			break;
		case SB:
			Modifier = strOption.GetAt(3);
			if(Modifier == SEND)
			{
				ch = SB;
				m_strResp += ch;
				m_strResp += Option;
				m_strResp += IS;
				m_strResp += IAC;
				m_strResp += SE;
			}
			break;
		}
	}

	else
	{
		switch(Verb)
		{
		case DO:
			ch = WONT;
			m_strResp += ch;
			m_strResp += Option;
			break;
		case DONT:
			ch = WONT;
			m_strResp += ch;
			m_strResp += Option;
			break;
		case WILL:
			ch = DONT;
			m_strResp += ch;
			m_strResp += Option;
			break;
		case WONT:
			ch = DONT;
			m_strResp += ch;
			m_strResp += Option;
			break;
		}
	}

}

//telnet������Ϣ
void CEHomeEIWrdDlg::DispatchMessage(CString strText)
{
	if(m_pSocket){
		int ret=m_pSocket->Send(strText, strText.GetLength());
		if(ret== SOCKET_ERROR)
			SocketError();
	}
}

void CEHomeEIWrdDlg::OnSelchangeCombo2() 
{
	// TODO: Add your control notification handler code here

	Invalidate(false);
	OnPaint();
}

void CEHomeEIWrdDlg::OnSelchangeCombo6() 
{
	// TODO: Add your control notification handler code here
	m_UserOper = m_cmb6.GetCurSel();
	Invalidate(false);
	OnPaint();
}

bool CEHomeEIWrdDlg::isValidKey(CString val, int size)
{
	bool ret = false;
	int len = val.GetLength();
	int dbSize = size * 2;
	int i;

	if ( len == size )
	  ret = true;
	else if ( len == dbSize ) {
	  for ( i = 0; i < dbSize; i++ )
		 if ( isHexaDigit(val[i]) == false )
			break;
	  if ( i == dbSize )
		 ret = true;
	} else
	  ret = false;

	return ret;
}

bool CEHomeEIWrdDlg::isHexaDigit(char digit)
{
	CString hexVals = _T("0123456789ABCDEFabcdef");
	int len = hexVals.GetLength();
	int i = 0;
	bool ret = false;

	for ( i = 0; i < len; i++ )
	  if ( digit == hexVals[i] ) break;

	if ( i < len )
	  ret = true;

	return ret;
}

bool CEHomeEIWrdDlg::isValidWPAPskKey(CString val)
{
	bool ret = false;
	int len = val.GetLength();
	int maxSize = 64;
	int minSize = 8;
	int i;

	if ( len >= minSize && len < maxSize )
		ret = true;
	else if ( len == maxSize ) {
		for ( i = 0; i < maxSize; i++ )
		if ( isHexaDigit(val[i]) == false )
		break;
		if ( i == maxSize )
		ret = true;
	} else
		ret = false;
	return ret;
}

bool CEHomeEIWrdDlg::isNameUnsafeEx(char compareChar)
{
   if ( compareChar > 32
        && compareChar < 127)
      return false; // found no unsafe chars, return false
   else
      return true;
}

// Check if a name valid
bool CEHomeEIWrdDlg::isValidNameEx(CString name)
{
   int i = 0;	
   
   for ( i = 0; i < name.GetLength(); i++ ) {
      if ( isNameUnsafeEx(name[i]) == true )
         return false;
   }

   return true;
}

void CEHomeEIWrdDlg::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	if(nIDEvent==TIMER_REG){
		if( ((m_statusFlag!=0)&&(m_statusFlag!=9)&&(m_statusFlag!=10)&&(m_init_Changed==1))
			|| ((m_retryTimes>=m_retryLimit)||(m_TimeOutCnt>=UpLimitCount)) ){
			KillTimer(TIMER_REG);
			m_TimeOutCnt=UpLimitCount;
		}
		else{
			if(m_Step==FIN_OPER){
				DispatchMessage(_T("tcapi get deviceAccount_Entry registerStatus\r\n"));
				m_Connected=22;
			}
			else
				KillTimer(TIMER_REG);
		}
		m_RegPageStatus=2;//tell the GUI it has pass 1 times(5s),can show the real message.
		m_Progress.SetPos(m_TimeOutCnt);
		Invalidate(false);
		OnPaint();
	}

	if(nIDEvent==TIMER_REFRESH){
		if(m_TimerCounter%5==0){
			m_TimerCounter=1;
			//it will confuse the telnet message,cancel it
			//DispatchMessage(_T("\r\n"));//keep the telnet alive
		}
		else
			m_TimerCounter++;

		Invalidate(false);
		//OnPaint();
	}
	
	if(nIDEvent==TIMER_UNLOCK){
		m_btnNext.EnableWindow(true);//enable next button
		m_btnPre.EnableWindow(true);//enable previous button
		m_btnCancel.EnableWindow(true);
		m_btnOK.EnableWindow(true);
		m_btnBrowser.EnableWindow(true);
		KillTimer(TIMER_UNLOCK);
	}

	CDialog::OnTimer(nIDEvent);
}

CString CEHomeEIWrdDlg::GetRegMsg() 
{
	CString msg;

	//this function will first time be called by OnOK->ProcessMessage->OnOnButtonNext()->refresh,
	//m_retryLimit will equal 0(initial value),because when it be used ,
	//the real value of m_retryLimit is still not be returned.
	if(m_retryLimit==0){
		 return m_CfgFile.GetString(APP_FIN_OPER, _T("Msg14"));
	}

	msg=GetMsg();

	//if no change,show wait until timeout ,show success or others at last.
	if(m_init_Changed==0){
		if(m_TimeOutCnt>=UpLimitCount){
			if(m_retryLimit - m_retryTimes<= 0){//��ʾ�û��Ѿ��������Դ�����3���Ӻ�CPE�����
				return m_CfgFile.GetString(APP_FIN_OPER, _T("Msg15"));
			}
			else if(m_statusFlag==0){
				return m_CfgFile.GetString(APP_FIN_OPER, _T("Msg16"));
			}
			else
				return msg;
		}
		else
			return m_CfgFile.GetString(APP_FIN_OPER, _T("Msg14"));
	}

	if(m_retryLimit - m_retryTimes<= 0){
		return m_CfgFile.GetString(APP_FIN_OPER, _T("Msg15"));
	}

	if(m_RegPageStatus==1){
		if((m_statusFlag==9)||(m_statusFlag==10))
			return msg;
		else
			return m_CfgFile.GetString(APP_FIN_OPER, _T("Msg14"));
	}

	if(m_RegPageStatus==2){
		if((m_statusFlag!=0)&&(m_statusFlag!=9)&&(m_statusFlag!=10)){			
			return msg;
		}
		else{
			if(m_TimeOutCnt<UpLimitCount){
				if((m_statusFlag==9)||(m_statusFlag==10))
					return msg;
				else
					return m_CfgFile.GetString(APP_FIN_OPER, _T("Msg14"));
			}
			else{
				if(m_statusFlag==0){
					return m_CfgFile.GetString(APP_FIN_OPER, _T("Msg16"));
				}
				else
					return msg;
			}
		}
	}

	return m_CfgFile.GetString(APP_FIN_OPER, _T("Msg14"));
}

CString CEHomeEIWrdDlg::GetMsg()
{
	CString retStr;
	int lefttime = m_retryLimit - m_retryTimes - 1;

	m_tryTimesflg=0;

	if(m_registerStatus == 99)
	{
		m_statusFlag = 0;
		return m_CfgFile.GetString(APP_FIN_OPER, _T("Msg1"));
	}		
	else if (m_registerStatus == 1)
	{
		m_statusFlag = 1;
		m_tryTimesflg=1;
		if(m_retryTimes < (m_retryLimit-1))
		{
			retStr.Format(m_CfgFile.GetString(APP_FIN_OPER, _T("Msg2")),lefttime);
			return retStr;
		}
		else
		{			
			return m_CfgFile.GetString(APP_FIN_OPER, _T("Msg3"));
		}
	}
	else if (m_registerStatus == 2)
	{
		m_statusFlag = 2;
		m_tryTimesflg=1;
		if(m_retryTimes < (m_retryLimit-1))
		{					
			retStr.Format(m_CfgFile.GetString(APP_FIN_OPER, _T("Msg4")),lefttime);
			return retStr;
		}
		else
		{			
			return m_CfgFile.GetString(APP_FIN_OPER, _T("Msg5"));
		}
	}
	else if (m_registerStatus == 3)
	{
		m_statusFlag = 3;
		m_tryTimesflg=1;
		if(m_retryTimes < (m_retryLimit-1))
		{									
			retStr.Format(m_CfgFile.GetString(APP_FIN_OPER, _T("Msg6")),lefttime);
			return retStr;
		}
		else
		{
			return m_CfgFile.GetString(APP_FIN_OPER, _T("Msg7"));
		}			
	}
	else if (m_registerStatus == 4)
	{
		m_statusFlag = 4;
		m_tryTimesflg=1;
		return m_CfgFile.GetString(APP_FIN_OPER, _T("Msg8"));
	}
	else if (m_registerStatus == 5)
	{
		m_statusFlag = 5;
		m_isRegSuccess = true;
		return m_CfgFile.GetString(APP_FIN_OPER, _T("Msg9"));
	}	
	else if (m_registerStatus == 0)
	{
		if(m_registerResult == 1)
		{
			m_statusFlag = 7;
			m_isRegSuccess = true;
			if(m_registerNeedReboot==1)
				return m_CfgFile.GetString(APP_FIN_OPER, _T("Msg10_1"));
			else
				return m_CfgFile.GetString(APP_FIN_OPER, _T("Msg10_0"));
		}
		else if(m_registerResult == 2)
		{
			m_statusFlag = 8;
			return m_CfgFile.GetString(APP_FIN_OPER, _T("Msg11"));
		}
		else if(m_registerResult == 99)
		{
			m_statusFlag = 9;
			m_isRegSuccess = true;
			return m_CfgFile.GetString(APP_FIN_OPER, _T("Msg12"));
		}
		else if(m_registerResult == 0)
		{
			m_statusFlag = 10;
			m_isRegSuccess = true;
			return m_CfgFile.GetString(APP_FIN_OPER, _T("Msg13"));
		}
	}
	return m_CfgFile.GetString(APP_FIN_OPER, _T("Msg0"));
}

int CEHomeEIWrdDlg::SplitString(const CString& strInputString, const CString& strDelimiter, CStringArray& arrStringArray)
{
	int iPos = 0;
	int newPos = -1;
	int sizeS2 = strDelimiter.GetLength();
	int isize = strInputString.GetLength();
	
	CArray<INT, int> positions;
	
	newPos = strInputString.Find (strDelimiter, 0);
	
	if( newPos < 0 )
		return 0;
	
	int numFound = 0;
	
	while( newPos > iPos )
	{
		numFound++;
		positions.Add(newPos);
		iPos = newPos;
		newPos = strInputString.Find (strDelimiter, iPos + sizeS2);
	}
	
	for( int i=0; i <= positions.GetSize(); i++ )
	{
		CString s;
		if( i == 0 )
			s = strInputString.Mid( i, positions[i] );
		else
		{
			int offset = positions[i-1] + sizeS2;
			if( offset < isize )
			{
				if( i == positions.GetSize() )
					s = strInputString.Mid(offset);
				else if( i > 0 )
					s = strInputString.Mid( positions[i-1] + sizeS2, positions[i] - positions[i-1] - sizeS2 );
			}
		}
		arrStringArray.Add(s);
	}
	return numFound;
}

void CEHomeEIWrdDlg::OnGotobrowser() 
{
	// TODO: Add your control notification handler code here
	m_btnBrowser.EnableWindow(false);
	HINSTANCE hRun=ShellExecute(NULL, "open", "IEXPLORE.EXE", HTTP_PREFIX+m_SvrHost, NULL, SW_SHOWMAXIMIZED);	
	//if((int)hRun<=32)
	//	AfxMessageBox("Open Browser Error!");
	if((int)hRun<=32)
		hRun=ShellExecute(NULL, "open", "FIREFOX.EXE", HTTP_PREFIX+m_SvrHost, NULL, SW_SHOWMAXIMIZED);
	if((int)hRun<=32)
		hRun=ShellExecute(NULL, "open", "CHROME.EXE", HTTP_PREFIX+m_SvrHost, NULL, SW_SHOWMAXIMIZED);

	SetTimer(TIMER_UNLOCK, TIMER_INTERVAL_UNLOCK, NULL);
}

void CEHomeEIWrdDlg::SocketError() 
{
	AfxMessageBox(m_CfgFile.GetString(APP_ERR_MSG, _T("Err10")),MB_OK);
	CDialog::OnOK();	
}
