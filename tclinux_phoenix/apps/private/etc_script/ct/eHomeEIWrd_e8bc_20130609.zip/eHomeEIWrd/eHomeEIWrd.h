// eHomeEIWrd.h : main header file for the EHOMEEIWRD application
//

#if !defined(AFX_EHOMEEIWRD_H__C36F36B0_8AB0_4AE4_916F_4179ED87D22C__INCLUDED_)
#define AFX_EHOMEEIWRD_H__C36F36B0_8AB0_4AE4_916F_4179ED87D22C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CEHomeEIWrdApp:
// See eHomeEIWrd.cpp for the implementation of this class
//

class CEHomeEIWrdApp : public CWinApp
{
public:
	CEHomeEIWrdApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEHomeEIWrdApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CEHomeEIWrdApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EHOMEEIWRD_H__C36F36B0_8AB0_4AE4_916F_4179ED87D22C__INCLUDED_)
